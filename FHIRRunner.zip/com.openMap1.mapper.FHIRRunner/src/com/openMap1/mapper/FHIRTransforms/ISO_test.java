package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;


public class ISO_test extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Wed Feb 07 15:11:30 GMT 2018");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}

// Document for transform result
private Document tDoc;


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public Element transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   tDoc = makeOutDoc();
   return topRule(root);
}

//--------------------------------------------------------------------------------------
//                                  Bundle                                  
//--------------------------------------------------------------------------------------

/**
* @param sourceTop
*/
protected Element topRule(Element sourceTop) throws Exception
{
    if (!("database".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'database'");
    Element target = newElement(tDoc,"Batch");
    tDoc.appendChild(target);
    target.setAttribute("xmlns:xs","http://www.w3.org/2001/XMLSchema");
    target.setAttribute("xmlns","urn:iso:std:iso:20022:tech:xsd:pain.001.001.08");

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rDocument(stack1, target);
    return target;
}

/**
* @param stack - source elements (0)database; 
* @param target - reached by target path: Batch
*/
protected void rDocument(List<Element> stack, Element target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sGROUP : namedChildElements(sourceTop,"GROUP_HEADER"))
    {
        List<Element> stack1 = push(sGROUP,stack);
         for(Element sRecord : namedChildElements(sGROUP,"record"))
         {
             Element t_Document_Document = newElement(tDoc,"Document");
             target.appendChild(t_Document_Document);
             Element t_CstmrCdtTrfInitn_C = newElement(tDoc,"CstmrCdtTrfInitn");
             t_Document_Document.appendChild(t_CstmrCdtTrfInitn_C);
             Element t_GrpHdr_GroupHeader = newElement(tDoc,"GrpHdr");
             t_CstmrCdtTrfInitn_C.appendChild(t_GrpHdr_GroupHeader);
             List<Element> stack2 = push(sRecord,stack1);

             Node sMsgId = namedChildNode(sRecord,"MSG_ID");
             if (sMsgId != null) t_GrpHdr_GroupHeader.appendChild(textElement(tDoc,"MsgId",getText(sMsgId)));

             Node sCreDtTm = namedChildNode(sRecord,"CREATED");
             if (sCreDtTm != null) t_GrpHdr_GroupHeader.appendChild(textElement(tDoc,"CreDtTm",getText(sCreDtTm)));

             Node sNbOfTxs = namedChildNode(sRecord,"TX_COUNT");
             if (sNbOfTxs != null) t_GrpHdr_GroupHeader.appendChild(textElement(tDoc,"NbOfTxs",getText(sNbOfTxs)));
             rPartyIdentification(stack2, t_GrpHdr_GroupHeader);
             rPaymentInstruction2(stack2, t_CstmrCdtTrfInitn_C);
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; 
* @param t_GrpHdr_GroupHeader - reached by target path: Batch.Document.CstmrCdtTrfInitn.GrpHdr
*/
protected void rPartyIdentification(List<Element> stack, Element t_GrpHdr_GroupHeader) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDRESS : namedChildElements(sourceTop,"ADDRESS"))
    {
        List<Element> stack1 = push(sADDRESS,stack);
         Element sRecord = stack1.get(2);
         for(Element sRecord_1 : namedChildElements(sADDRESS,"record"))
         if ( crossTest(sRecord_1, "PARTY_NAME", sRecord, "INIT_NAME") &&  crossTest(sRecord_1, "ADDR", sRecord, "INIT_ADDR"))
         {
             Element t_InitgPty_PartyIden = newElement(tDoc,"InitgPty");
             t_GrpHdr_GroupHeader.appendChild(t_InitgPty_PartyIden);
             Element t_PstlAdr_PostalAddr_2 = newElement(tDoc,"PstlAdr");
             t_InitgPty_PartyIden.appendChild(t_PstlAdr_PostalAddr_2);
             List<Element> stack2 = push(sRecord_1,stack1);

             Node sNm = namedChildNode(sRecord_1,"PARTY_NAME");
             if (sNm != null) t_InitgPty_PartyIden.appendChild(textElement(tDoc,"Nm",getText(sNm)));

             Node sStrtNm = namedChildNode(sRecord_1,"STREET");
             if (sStrtNm != null) t_PstlAdr_PostalAddr_2.appendChild(textElement(tDoc,"StrtNm",getText(sStrtNm)));

             Node sBldgNb = namedChildNode(sRecord_1,"BUILDING_NBR");
             if (sBldgNb != null) t_PstlAdr_PostalAddr_2.appendChild(textElement(tDoc,"BldgNb",getText(sBldgNb)));

             Node sPstCd = namedChildNode(sRecord_1,"POST_CODE");
             if (sPstCd != null) t_PstlAdr_PostalAddr_2.appendChild(textElement(tDoc,"PstCd",getText(sPstCd)));

             Node sTwnNm = namedChildNode(sRecord_1,"TOWN");
             if (sTwnNm != null) t_PstlAdr_PostalAddr_2.appendChild(textElement(tDoc,"TwnNm",getText(sTwnNm)));

             Node sCtry = namedChildNode(sRecord_1,"COUNTRY");
             if (sCtry != null) t_PstlAdr_PostalAddr_2.appendChild(textElement(tDoc,"Ctry",getText(sCtry)));
             rMax70Text(stack2, t_PstlAdr_PostalAddr_2);
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)ADDRESS; (4)record; 
* @param t_PstlAdr_PostalAddr_2 - reached by target path: Batch.Document.CstmrCdtTrfInitn.GrpHdr.InitgPty.PstlAdr
*/
protected void rMax70Text(List<Element> stack, Element t_PstlAdr_PostalAddr_2) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDR : namedChildElements(sourceTop,"ADDR_LINES"))
    {
        List<Element> stack1 = push(sADDR,stack);
         Element sRecord_1 = stack1.get(4);
         for(Element sRecord_2 : namedChildElements(sADDR,"record"))
         if ( crossTest(sRecord_2, "PARTY_NAME", sRecord_1, "PARTY_NAME") &&  crossTest(sRecord_2, "ADDR", sRecord_1, "ADDR"))
         {
             Element t_AdrLine_Max70Text_2 = newElement(tDoc,"AdrLine");
             t_PstlAdr_PostalAddr_2.appendChild(t_AdrLine_Max70Text_2);
             List<Element> stack2 = push(sRecord_2,stack1);

             Node sTextValue = namedChildNode(sRecord_2,"ADDRESS");
             if (sTextValue != null) t_AdrLine_Max70Text_2.appendChild(textElement(tDoc,"textValue",getText(sTextValue)));
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; 
* @param t_CstmrCdtTrfInitn_C - reached by target path: Batch.Document.CstmrCdtTrfInitn
*/
protected void rPaymentInstruction2(List<Element> stack, Element t_CstmrCdtTrfInitn_C) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPAYMENT : namedChildElements(sourceTop,"PAYMENT_INST"))
    {
        List<Element> stack1 = push(sPAYMENT,stack);
         Element sRecord = stack1.get(2);
         for(Element sRecord_3 : namedChildElements(sPAYMENT,"record"))
         if ( crossTest(sRecord_3, "PAYMT_MSG_ID", sRecord, "MSG_ID"))
         {
             Element t_PmtInf_PaymentInst = newElement(tDoc,"PmtInf");
             t_CstmrCdtTrfInitn_C.appendChild(t_PmtInf_PaymentInst);
             Element t_ReqdExctnDt_DateAn = newElement(tDoc,"ReqdExctnDt");
             t_PmtInf_PaymentInst.appendChild(t_ReqdExctnDt_DateAn);
             Element t_DbtrAcct_CashAccou = newElement(tDoc,"DbtrAcct");
             t_PmtInf_PaymentInst.appendChild(t_DbtrAcct_CashAccou);
             Element t_Id_AccountIdentifi_1 = newElement(tDoc,"Id");
             t_DbtrAcct_CashAccou.appendChild(t_Id_AccountIdentifi_1);
             List<Element> stack2 = push(sRecord_3,stack1);

             Node sPmtInfId = namedChildNode(sRecord_3,"PAYMT_ID");
             if (sPmtInfId != null) t_PmtInf_PaymentInst.appendChild(textElement(tDoc,"PmtInfId",getText(sPmtInfId)));

             Node sIBAN = namedChildNode(sRecord_3,"DEBTOR_ACCOUNT");
             if (sIBAN != null) t_Id_AccountIdentifi_1.appendChild(textElement(tDoc,"IBAN",getText(sIBAN)));

             Node sDt = namedChildNode(sRecord_3,"REQ_DATE");
             if (sDt != null) t_ReqdExctnDt_DateAn.appendChild(textElement(tDoc,"Dt",getText(sDt)));
             rPartyIdentification_1(stack2, t_PmtInf_PaymentInst);
             rGenericAccountIdent(stack2, t_Id_AccountIdentifi_1);
             rCreditTransferTrans(stack2, t_PmtInf_PaymentInst);
             rBranchAndFinancialI_1(stack2, t_PmtInf_PaymentInst);
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_PmtInf_PaymentInst - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
protected void rPartyIdentification_1(List<Element> stack, Element t_PmtInf_PaymentInst) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDRESS_1 : namedChildElements(sourceTop,"ADDRESS"))
    {
        List<Element> stack1 = push(sADDRESS_1,stack);
         Element sRecord_3 = stack1.get(4);
         for(Element sRecord_4 : namedChildElements(sADDRESS_1,"record"))
         if ( crossTest(sRecord_4, "PARTY_NAME", sRecord_3, "DEBTOR_NAME") &&  crossTest(sRecord_4, "ADDR", sRecord_3, "DEBTOR_ADDR"))
         {
             Element t_Dbtr_PartyIdentifi = newElement(tDoc,"Dbtr");
             t_PmtInf_PaymentInst.appendChild(t_Dbtr_PartyIdentifi);
             Element t_PstlAdr_PostalAddr = newElement(tDoc,"PstlAdr");
             t_Dbtr_PartyIdentifi.appendChild(t_PstlAdr_PostalAddr);
             List<Element> stack2 = push(sRecord_4,stack1);

             Node sNm_1 = namedChildNode(sRecord_4,"PARTY_NAME");
             if (sNm_1 != null) t_Dbtr_PartyIdentifi.appendChild(textElement(tDoc,"Nm",getText(sNm_1)));

             Node sStrtNm_1 = namedChildNode(sRecord_4,"STREET");
             if (sStrtNm_1 != null) t_PstlAdr_PostalAddr.appendChild(textElement(tDoc,"StrtNm",getText(sStrtNm_1)));

             Node sBldgNb_1 = namedChildNode(sRecord_4,"BUILDING_NBR");
             if (sBldgNb_1 != null) t_PstlAdr_PostalAddr.appendChild(textElement(tDoc,"BldgNb",getText(sBldgNb_1)));

             Node sPstCd_1 = namedChildNode(sRecord_4,"POST_CODE");
             if (sPstCd_1 != null) t_PstlAdr_PostalAddr.appendChild(textElement(tDoc,"PstCd",getText(sPstCd_1)));

             Node sTwnNm_1 = namedChildNode(sRecord_4,"TOWN");
             if (sTwnNm_1 != null) t_PstlAdr_PostalAddr.appendChild(textElement(tDoc,"TwnNm",getText(sTwnNm_1)));

             Node sCtry_1 = namedChildNode(sRecord_4,"COUNTRY");
             if (sCtry_1 != null) t_PstlAdr_PostalAddr.appendChild(textElement(tDoc,"Ctry",getText(sCtry_1)));
             rMax70Text_1(stack2, t_PstlAdr_PostalAddr);
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)ADDRESS; (6)record; 
* @param t_PstlAdr_PostalAddr - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.Dbtr.PstlAdr
*/
protected void rMax70Text_1(List<Element> stack, Element t_PstlAdr_PostalAddr) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDR_1 : namedChildElements(sourceTop,"ADDR_LINES"))
    {
        List<Element> stack1 = push(sADDR_1,stack);
         Element sRecord_4 = stack1.get(6);
         for(Element sRecord_5 : namedChildElements(sADDR_1,"record"))
         if ( crossTest(sRecord_5, "PARTY_NAME", sRecord_4, "PARTY_NAME") &&  crossTest(sRecord_5, "ADDR", sRecord_4, "ADDR"))
         {
             Element t_AdrLine_Max70Text = newElement(tDoc,"AdrLine");
             t_PstlAdr_PostalAddr.appendChild(t_AdrLine_Max70Text);
             List<Element> stack2 = push(sRecord_5,stack1);

             Node sTextValue_1 = namedChildNode(sRecord_5,"ADDRESS");
             if (sTextValue_1 != null) t_AdrLine_Max70Text.appendChild(textElement(tDoc,"textValue",getText(sTextValue_1)));
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_Id_AccountIdentifi_1 - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.DbtrAcct.Id
*/
protected void rGenericAccountIdent(List<Element> stack, Element t_Id_AccountIdentifi_1) throws Exception
{
    Element sRecord_3 = stack.get(4);
    Element sRecord_6 = sRecord_3;
    if (valueTest(sRecord_6,"PAYMT_MSG_ID", "ABC/120928/CCT001","="))
    {
        Element t_Othr_GenericAccoun_1 = newElement(tDoc,"Othr");
        t_Id_AccountIdentifi_1.appendChild(t_Othr_GenericAccoun_1);
        List<Element> stack1 = push(sRecord_6,stack);

        Node sId = namedChildNode(sRecord_6,"DEBTOR_ACCOUNT");
        if (sId != null) t_Othr_GenericAccoun_1.appendChild(textElement(tDoc,"Id",getText(sId)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_PmtInf_PaymentInst - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
protected void rCreditTransferTrans(List<Element> stack, Element t_PmtInf_PaymentInst) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sCREDIT : namedChildElements(sourceTop,"CREDIT_TX"))
    {
        List<Element> stack1 = push(sCREDIT,stack);
         Element sRecord_3 = stack1.get(4);
         for(Element sRecord_7 : namedChildElements(sCREDIT,"record"))
         if ( crossTest(sRecord_7, "PAYMT_MSG_ID", sRecord_3, "PAYMT_MSG_ID") &&  crossTest(sRecord_7, "PAYMT_ID", sRecord_3, "PAYMT_ID"))
         {
             Element t_CdtTrfTxInf_Credit = newElement(tDoc,"CdtTrfTxInf");
             t_PmtInf_PaymentInst.appendChild(t_CdtTrfTxInf_Credit);
             Element t_PmtId_PaymentIdent = newElement(tDoc,"PmtId");
             t_CdtTrfTxInf_Credit.appendChild(t_PmtId_PaymentIdent);
             Element t_Amt_AmountType4Cho = newElement(tDoc,"Amt");
             t_CdtTrfTxInf_Credit.appendChild(t_Amt_AmountType4Cho);
             Element t_CdtrAcct_CashAccou = newElement(tDoc,"CdtrAcct");
             t_CdtTrfTxInf_Credit.appendChild(t_CdtrAcct_CashAccou);
             Element t_RmtInf_RemittanceI = newElement(tDoc,"RmtInf");
             t_CdtTrfTxInf_Credit.appendChild(t_RmtInf_RemittanceI);
             Element t_InstdAmt_ActiveOrH = newElement(tDoc,"InstdAmt");
             t_Amt_AmountType4Cho.appendChild(t_InstdAmt_ActiveOrH);
             Element t_Id_AccountIdentifi = newElement(tDoc,"Id");
             t_CdtrAcct_CashAccou.appendChild(t_Id_AccountIdentifi);
             Element t_Strd_StructuredRem = newElement(tDoc,"Strd");
             t_RmtInf_RemittanceI.appendChild(t_Strd_StructuredRem);
             Element t_RfrdDocInf_Referre = newElement(tDoc,"RfrdDocInf");
             t_Strd_StructuredRem.appendChild(t_RfrdDocInf_Referre);
             List<Element> stack2 = push(sRecord_7,stack1);

             Node sEndToEndId = namedChildNode(sRecord_7,"TX_ID");
             if (sEndToEndId != null) t_PmtId_PaymentIdent.appendChild(textElement(tDoc,"EndToEndId",getText(sEndToEndId)));

             Node sCcy = namedChildNode(sRecord_7,"CURRENCY");
             if (sCcy != null) t_InstdAmt_ActiveOrH.setAttribute("Ccy",getText(sCcy));

             Node sIBAN_1 = namedChildNode(sRecord_7,"CREDITOR_ACCOUNT");
             if (sIBAN_1 != null) t_Id_AccountIdentifi.appendChild(textElement(tDoc,"IBAN",getText(sIBAN_1)));

             Node sRltdDt = namedChildNode(sRecord_7,"REL_DATE");
             if (sRltdDt != null) t_RfrdDocInf_Referre.appendChild(textElement(tDoc,"RltdDt",getText(sRltdDt)));
             rPartyIdentification_2(stack2, t_CdtTrfTxInf_Credit);
             rGenericAccountIdent_1(stack2, t_Id_AccountIdentifi);
             rInstructionForCredi(stack2, t_CdtTrfTxInf_Credit);
             rBranchAndFinancialI(stack2, t_CdtTrfTxInf_Credit);
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; 
* @param t_CdtTrfTxInf_Credit - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf
*/
protected void rPartyIdentification_2(List<Element> stack, Element t_CdtTrfTxInf_Credit) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDRESS_2 : namedChildElements(sourceTop,"ADDRESS"))
    {
        List<Element> stack1 = push(sADDRESS_2,stack);
         Element sRecord_7 = stack1.get(6);
         for(Element sRecord_8 : namedChildElements(sADDRESS_2,"record"))
         if ( crossTest(sRecord_8, "PARTY_NAME", sRecord_7, "CREDITOR_NAME") &&  crossTest(sRecord_8, "ADDR", sRecord_7, "CREDITOR_ADDR"))
         {
             Element t_Cdtr_PartyIdentifi = newElement(tDoc,"Cdtr");
             t_CdtTrfTxInf_Credit.appendChild(t_Cdtr_PartyIdentifi);
             Element t_PstlAdr_PostalAddr_1 = newElement(tDoc,"PstlAdr");
             t_Cdtr_PartyIdentifi.appendChild(t_PstlAdr_PostalAddr_1);
             List<Element> stack2 = push(sRecord_8,stack1);

             Node sNm_2 = namedChildNode(sRecord_8,"PARTY_NAME");
             if (sNm_2 != null) t_Cdtr_PartyIdentifi.appendChild(textElement(tDoc,"Nm",getText(sNm_2)));

             Node sDept = namedChildNode(sRecord_8,"DEPT");
             if (sDept != null) t_PstlAdr_PostalAddr_1.appendChild(textElement(tDoc,"Dept",getText(sDept)));

             Node sStrtNm_2 = namedChildNode(sRecord_8,"STREET");
             if (sStrtNm_2 != null) t_PstlAdr_PostalAddr_1.appendChild(textElement(tDoc,"StrtNm",getText(sStrtNm_2)));

             Node sBldgNb_2 = namedChildNode(sRecord_8,"BUILDING_NBR");
             if (sBldgNb_2 != null) t_PstlAdr_PostalAddr_1.appendChild(textElement(tDoc,"BldgNb",getText(sBldgNb_2)));

             Node sPstCd_2 = namedChildNode(sRecord_8,"POST_CODE");
             if (sPstCd_2 != null) t_PstlAdr_PostalAddr_1.appendChild(textElement(tDoc,"PstCd",getText(sPstCd_2)));

             Node sTwnNm_2 = namedChildNode(sRecord_8,"TOWN");
             if (sTwnNm_2 != null) t_PstlAdr_PostalAddr_1.appendChild(textElement(tDoc,"TwnNm",getText(sTwnNm_2)));

             Node sCtry_2 = namedChildNode(sRecord_8,"COUNTRY");
             if (sCtry_2 != null) t_PstlAdr_PostalAddr_1.appendChild(textElement(tDoc,"Ctry",getText(sCtry_2)));
             rMax70Text_2(stack2, t_PstlAdr_PostalAddr_1);
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; (7)ADDRESS; (8)record; 
* @param t_PstlAdr_PostalAddr_1 - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf.Cdtr.PstlAdr
*/
protected void rMax70Text_2(List<Element> stack, Element t_PstlAdr_PostalAddr_1) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDR_2 : namedChildElements(sourceTop,"ADDR_LINES"))
    {
        List<Element> stack1 = push(sADDR_2,stack);
         Element sRecord_8 = stack1.get(8);
         for(Element sRecord_9 : namedChildElements(sADDR_2,"record"))
         if ( crossTest(sRecord_9, "PARTY_NAME", sRecord_8, "PARTY_NAME") &&  crossTest(sRecord_9, "ADDR", sRecord_8, "ADDR"))
         {
             Element t_AdrLine_Max70Text_1 = newElement(tDoc,"AdrLine");
             t_PstlAdr_PostalAddr_1.appendChild(t_AdrLine_Max70Text_1);
             List<Element> stack2 = push(sRecord_9,stack1);

             Node sTextValue_2 = namedChildNode(sRecord_9,"ADDRESS");
             if (sTextValue_2 != null) t_AdrLine_Max70Text_1.appendChild(textElement(tDoc,"textValue",getText(sTextValue_2)));
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; 
* @param t_Id_AccountIdentifi - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf.CdtrAcct.Id
*/
protected void rGenericAccountIdent_1(List<Element> stack, Element t_Id_AccountIdentifi) throws Exception
{
    Element sRecord_7 = stack.get(6);
    Element sRecord_10 = sRecord_7;
    if (valueTest(sRecord_10,"CREDITOR_IBAN", "N","="))
    {
        Element t_Othr_GenericAccoun = newElement(tDoc,"Othr");
        t_Id_AccountIdentifi.appendChild(t_Othr_GenericAccoun);
        List<Element> stack1 = push(sRecord_10,stack);

        Node sId_1 = namedChildNode(sRecord_10,"CREDITOR_ACCOUNT");
        if (sId_1 != null) t_Othr_GenericAccoun.appendChild(textElement(tDoc,"Id",getText(sId_1)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; 
* @param t_CdtTrfTxInf_Credit - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf
*/
protected void rInstructionForCredi(List<Element> stack, Element t_CdtTrfTxInf_Credit) throws Exception
{
    Element sRecord_7 = stack.get(6);
    Element sRecord_11 = sRecord_7;
    if (valueTest(sRecord_11,"CURRENCY", "EUR","="))
    {
        Element t_InstrForCdtrAgt_In = newElement(tDoc,"InstrForCdtrAgt");
        t_CdtTrfTxInf_Credit.appendChild(t_InstrForCdtrAgt_In);
        List<Element> stack1 = push(sRecord_11,stack);

        Node sCd = namedChildNode(sRecord_11,"INST_CREDITOR_AGENT");
        if (sCd != null) t_InstrForCdtrAgt_In.appendChild(textElement(tDoc,"Cd",getText(sCd)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; 
* @param t_CdtTrfTxInf_Credit - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf
*/
protected void rBranchAndFinancialI(List<Element> stack, Element t_CdtTrfTxInf_Credit) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sBANK : namedChildElements(sourceTop,"BANK"))
    {
        List<Element> stack1 = push(sBANK,stack);
         Element sRecord_7 = stack1.get(6);
         for(Element sRecord_12 : namedChildElements(sBANK,"record"))
         if ( crossTest(sRecord_12, "PARTY_NAME", sRecord_7, "CREDITOR_NAME") && valueTest(sRecord_12,"BANK", "01","="))
         {
             Element t_CdtrAgt_BranchAndF = newElement(tDoc,"CdtrAgt");
             t_CdtTrfTxInf_Credit.appendChild(t_CdtrAgt_BranchAndF);
         }
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_PmtInf_PaymentInst - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
protected void rBranchAndFinancialI_1(List<Element> stack, Element t_PmtInf_PaymentInst) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sBANK_1 : namedChildElements(sourceTop,"BANK"))
    {
        List<Element> stack1 = push(sBANK_1,stack);
         Element sRecord_3 = stack1.get(4);
         for(Element sRecord_13 : namedChildElements(sBANK_1,"record"))
         if ( crossTest(sRecord_13, "PARTY_NAME", sRecord_3, "DEBTOR_NAME") && valueTest(sRecord_13,"BANK", "01","="))
         {
             Element t_DbtrAgt_BranchAndF = newElement(tDoc,"DbtrAgt");
             t_PmtInf_PaymentInst.appendChild(t_DbtrAgt_BranchAndF);
             Element t_FinInstnId_Financi = newElement(tDoc,"FinInstnId");
             t_DbtrAgt_BranchAndF.appendChild(t_FinInstnId_Financi);
             List<Element> stack2 = push(sRecord_13,stack1);

             Node sBICFI = namedChildNode(sRecord_13,"BIC");
             if (sBICFI != null) t_FinInstnId_Financi.appendChild(textElement(tDoc,"BICFI",getText(sBICFI)));
         }
    }
}
}
