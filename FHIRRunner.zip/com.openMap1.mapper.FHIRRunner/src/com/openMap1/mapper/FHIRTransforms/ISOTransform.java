package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;


public class ISOTransform extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Sun Oct 08 20:43:35 BST 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}

// Document for transform result
private Document tDoc;


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public Element transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   tDoc = makeOutDoc();
   return topRule(root);
}

/**
* @param sourceTop
*/
private Element topRule(Element sourceTop) throws Exception
{
    if (!("database".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'database'");
    Element target = newElement(tDoc,"Batch");
    tDoc.appendChild(target);

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rFiller(stack1, target);
    return target;
}

/**
* @param stack - source elements (0)database; 
* @param target - reached by target path: Batch
*/
private void rFiller(List<Element> stack, Element target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sGROUP : namedChildElements(sourceTop,"GROUP_HEADER"))
    {

        List<Element> stack1 = push(sGROUP,stack);
        rDocument(stack1, target);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; 
* @param target - reached by target path: Batch
*/
private void rDocument(List<Element> stack, Element target) throws Exception
{
    Element sGROUP = stack.get(1);
    for(Element sRecord : namedChildElements(sGROUP,"record"))
    {
        Element t_Document = newElement(tDoc,"Document");
        target.appendChild(t_Document);
        Element t_CstmrCdtTrfI = newElement(tDoc,"CstmrCdtTrfInitn");
        t_Document.appendChild(t_CstmrCdtTrfI);
        Element t_GrpHdr = newElement(tDoc,"GrpHdr");
        t_CstmrCdtTrfI.appendChild(t_GrpHdr);

        List<Element> stack1 = push(sRecord,stack);

        Node sMsgId = namedChildNode(sRecord,"MSG_ID");
        if (sMsgId != null) t_GrpHdr.appendChild(textElement(tDoc,"MsgId",getText(sMsgId)));

        Node sCreDtTm = namedChildNode(sRecord,"CREATED");
        if (sCreDtTm != null) t_GrpHdr.appendChild(textElement(tDoc,"CreDtTm",getText(sCreDtTm)));

        Node sNbOfTxs = namedChildNode(sRecord,"TX_COUNT");
        if (sNbOfTxs != null) t_GrpHdr.appendChild(textElement(tDoc,"NbOfTxs",getText(sNbOfTxs)));
        rFiller1(stack1, t_GrpHdr);
        rFiller3(stack1, t_CstmrCdtTrfI);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; 
* @param t_GrpHdr - reached by target path: Batch.Document.CstmrCdtTrfInitn.GrpHdr
*/
private void rFiller1(List<Element> stack, Element t_GrpHdr) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDRESS : namedChildElements(sourceTop,"ADDRESS"))
    {

        List<Element> stack1 = push(sADDRESS,stack);
        rPartyIdentifi(stack1, t_GrpHdr);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)ADDRESS; 
* @param t_GrpHdr - reached by target path: Batch.Document.CstmrCdtTrfInitn.GrpHdr
*/
private void rPartyIdentifi(List<Element> stack, Element t_GrpHdr) throws Exception
{
    Element sADDRESS = stack.get(3);
    Element sRecord = stack.get(2);
    for(Element sRecord1 : namedChildElements(sADDRESS,"record"))
    if ( crossTest(sRecord1, "PARTY_NAME", sRecord, "INIT_NAME") &&  crossTest(sRecord1, "ADDR", sRecord, "INIT_ADDR"))
    {
        Element t_InitgPty = newElement(tDoc,"InitgPty");
        t_GrpHdr.appendChild(t_InitgPty);
        Element t_PstlAdr2 = newElement(tDoc,"PstlAdr");
        t_InitgPty.appendChild(t_PstlAdr2);

        List<Element> stack1 = push(sRecord1,stack);

        Node sNm = namedChildNode(sRecord1,"PARTY_NAME");
        if (sNm != null) t_InitgPty.appendChild(textElement(tDoc,"Nm",getText(sNm)));

        Node sStrtNm = namedChildNode(sRecord1,"STREET");
        if (sStrtNm != null) t_PstlAdr2.appendChild(textElement(tDoc,"StrtNm",getText(sStrtNm)));

        Node sBldgNb = namedChildNode(sRecord1,"BUILDING_NBR");
        if (sBldgNb != null) t_PstlAdr2.appendChild(textElement(tDoc,"BldgNb",getText(sBldgNb)));

        Node sPstCd = namedChildNode(sRecord1,"POST_CODE");
        if (sPstCd != null) t_PstlAdr2.appendChild(textElement(tDoc,"PstCd",getText(sPstCd)));

        Node sTwnNm = namedChildNode(sRecord1,"TOWN");
        if (sTwnNm != null) t_PstlAdr2.appendChild(textElement(tDoc,"TwnNm",getText(sTwnNm)));

        Node sCtry = namedChildNode(sRecord1,"COUNTRY");
        if (sCtry != null) t_PstlAdr2.appendChild(textElement(tDoc,"Ctry",getText(sCtry)));
        rFiller2(stack1, t_PstlAdr2);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)ADDRESS; (4)record; 
* @param t_PstlAdr2 - reached by target path: Batch.Document.CstmrCdtTrfInitn.GrpHdr.InitgPty.PstlAdr
*/
private void rFiller2(List<Element> stack, Element t_PstlAdr2) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDR : namedChildElements(sourceTop,"ADDR_LINES"))
    {

        List<Element> stack1 = push(sADDR,stack);
        rMax70Text(stack1, t_PstlAdr2);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)ADDRESS; (4)record; (5)ADDR_LINES; 
* @param t_PstlAdr2 - reached by target path: Batch.Document.CstmrCdtTrfInitn.GrpHdr.InitgPty.PstlAdr
*/
private void rMax70Text(List<Element> stack, Element t_PstlAdr2) throws Exception
{
    Element sADDR = stack.get(5);
    Element sRecord1 = stack.get(4);
    for(Element sRecord2 : namedChildElements(sADDR,"record"))
    if ( crossTest(sRecord2, "PARTY_NAME", sRecord1, "PARTY_NAME") &&  crossTest(sRecord2, "ADDR", sRecord1, "ADDR"))
    {
        Element t_AdrLine2 = newElement(tDoc,"AdrLine");
        t_PstlAdr2.appendChild(t_AdrLine2);

        List<Element> stack1 = push(sRecord2,stack);

        Node sTextValue = namedChildNode(sRecord2,"ADDRESS");
        if (sTextValue != null) t_AdrLine2.appendChild(textElement(tDoc,"textValue",getText(sTextValue)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; 
* @param t_CstmrCdtTrfI - reached by target path: Batch.Document.CstmrCdtTrfInitn
*/
private void rFiller3(List<Element> stack, Element t_CstmrCdtTrfI) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPAYMENT : namedChildElements(sourceTop,"PAYMENT_INST"))
    {

        List<Element> stack1 = push(sPAYMENT,stack);
        rPaymentInstru(stack1, t_CstmrCdtTrfI);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; 
* @param t_CstmrCdtTrfI - reached by target path: Batch.Document.CstmrCdtTrfInitn
*/
private void rPaymentInstru(List<Element> stack, Element t_CstmrCdtTrfI) throws Exception
{
    Element sPAYMENT = stack.get(3);
    Element sRecord = stack.get(2);
    for(Element sRecord3 : namedChildElements(sPAYMENT,"record"))
    if ( crossTest(sRecord3, "PAYMT_MSG_ID", sRecord, "MSG_ID"))
    {
        Element t_PmtInf = newElement(tDoc,"PmtInf");
        t_CstmrCdtTrfI.appendChild(t_PmtInf);
        Element t_ReqdExctnDt = newElement(tDoc,"ReqdExctnDt");
        t_PmtInf.appendChild(t_ReqdExctnDt);
        Element t_DbtrAcct = newElement(tDoc,"DbtrAcct");
        t_PmtInf.appendChild(t_DbtrAcct);
        Element t_Id1 = newElement(tDoc,"Id");
        t_DbtrAcct.appendChild(t_Id1);

        List<Element> stack1 = push(sRecord3,stack);

        Node sPmtInfId = namedChildNode(sRecord3,"PAYMT_ID");
        if (sPmtInfId != null) t_PmtInf.appendChild(textElement(tDoc,"PmtInfId",getText(sPmtInfId)));

        Node sIBAN = namedChildNode(sRecord3,"DEBTOR_ACCOUNT");
        if (sIBAN != null) t_Id1.appendChild(textElement(tDoc,"IBAN",getText(sIBAN)));

        Node sDt = namedChildNode(sRecord3,"REQ_DATE");
        if (sDt != null) t_ReqdExctnDt.appendChild(textElement(tDoc,"Dt",getText(sDt)));
        rFiller4(stack1, t_PmtInf);
        rGenericAccoun(stack1, t_Id1);
        rFiller6(stack1, t_PmtInf);
        rFiller9(stack1, t_PmtInf);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_PmtInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
private void rFiller4(List<Element> stack, Element t_PmtInf) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDRESS1 : namedChildElements(sourceTop,"ADDRESS"))
    {

        List<Element> stack1 = push(sADDRESS1,stack);
        rPartyIdentifi1(stack1, t_PmtInf);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)ADDRESS; 
* @param t_PmtInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
private void rPartyIdentifi1(List<Element> stack, Element t_PmtInf) throws Exception
{
    Element sADDRESS1 = stack.get(5);
    Element sRecord3 = stack.get(4);
    for(Element sRecord4 : namedChildElements(sADDRESS1,"record"))
    if ( crossTest(sRecord4, "PARTY_NAME", sRecord3, "DEBTOR_NAME") &&  crossTest(sRecord4, "ADDR", sRecord3, "DEBTOR_ADDR"))
    {
        Element t_Dbtr = newElement(tDoc,"Dbtr");
        t_PmtInf.appendChild(t_Dbtr);
        Element t_PstlAdr = newElement(tDoc,"PstlAdr");
        t_Dbtr.appendChild(t_PstlAdr);

        List<Element> stack1 = push(sRecord4,stack);

        Node sNm1 = namedChildNode(sRecord4,"PARTY_NAME");
        if (sNm1 != null) t_Dbtr.appendChild(textElement(tDoc,"Nm",getText(sNm1)));

        Node sStrtNm1 = namedChildNode(sRecord4,"STREET");
        if (sStrtNm1 != null) t_PstlAdr.appendChild(textElement(tDoc,"StrtNm",getText(sStrtNm1)));

        Node sBldgNb1 = namedChildNode(sRecord4,"BUILDING_NBR");
        if (sBldgNb1 != null) t_PstlAdr.appendChild(textElement(tDoc,"BldgNb",getText(sBldgNb1)));

        Node sPstCd1 = namedChildNode(sRecord4,"POST_CODE");
        if (sPstCd1 != null) t_PstlAdr.appendChild(textElement(tDoc,"PstCd",getText(sPstCd1)));

        Node sTwnNm1 = namedChildNode(sRecord4,"TOWN");
        if (sTwnNm1 != null) t_PstlAdr.appendChild(textElement(tDoc,"TwnNm",getText(sTwnNm1)));

        Node sCtry1 = namedChildNode(sRecord4,"COUNTRY");
        if (sCtry1 != null) t_PstlAdr.appendChild(textElement(tDoc,"Ctry",getText(sCtry1)));
        rFiller5(stack1, t_PstlAdr);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)ADDRESS; (6)record; 
* @param t_PstlAdr - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.Dbtr.PstlAdr
*/
private void rFiller5(List<Element> stack, Element t_PstlAdr) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDR1 : namedChildElements(sourceTop,"ADDR_LINES"))
    {

        List<Element> stack1 = push(sADDR1,stack);
        rMax70Text1(stack1, t_PstlAdr);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)ADDRESS; (6)record; (7)ADDR_LINES; 
* @param t_PstlAdr - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.Dbtr.PstlAdr
*/
private void rMax70Text1(List<Element> stack, Element t_PstlAdr) throws Exception
{
    Element sADDR1 = stack.get(7);
    Element sRecord4 = stack.get(6);
    for(Element sRecord5 : namedChildElements(sADDR1,"record"))
    if ( crossTest(sRecord5, "PARTY_NAME", sRecord4, "PARTY_NAME") &&  crossTest(sRecord5, "ADDR", sRecord4, "ADDR"))
    {
        Element t_AdrLine = newElement(tDoc,"AdrLine");
        t_PstlAdr.appendChild(t_AdrLine);

        List<Element> stack1 = push(sRecord5,stack);

        Node sTextValue1 = namedChildNode(sRecord5,"ADDRESS");
        if (sTextValue1 != null) t_AdrLine.appendChild(textElement(tDoc,"textValue",getText(sTextValue1)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_Id1 - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.DbtrAcct.Id
*/
private void rGenericAccoun(List<Element> stack, Element t_Id1) throws Exception
{
    Element sRecord3 = stack.get(4);
    Element sRecord6 = sRecord3;
    if (valueTest(sRecord6,"PAYMT_MSG_ID", "ABC/120928/CCT001","="))
    {
        Element t_Othr1 = newElement(tDoc,"Othr");
        t_Id1.appendChild(t_Othr1);

        List<Element> stack1 = push(sRecord6,stack);

        Node sId = namedChildNode(sRecord6,"DEBTOR_ACCOUNT");
        if (sId != null) t_Othr1.appendChild(textElement(tDoc,"Id",getText(sId)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_PmtInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
private void rFiller6(List<Element> stack, Element t_PmtInf) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sCREDIT : namedChildElements(sourceTop,"CREDIT_TX"))
    {

        List<Element> stack1 = push(sCREDIT,stack);
        rCreditTransfe(stack1, t_PmtInf);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; 
* @param t_PmtInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
private void rCreditTransfe(List<Element> stack, Element t_PmtInf) throws Exception
{
    Element sCREDIT = stack.get(5);
    Element sRecord3 = stack.get(4);
    for(Element sRecord7 : namedChildElements(sCREDIT,"record"))
    if ( crossTest(sRecord7, "PAYMT_MSG_ID", sRecord3, "PAYMT_MSG_ID") &&  crossTest(sRecord7, "PAYMT_ID", sRecord3, "PAYMT_ID"))
    {
        Element t_CdtTrfTxInf = newElement(tDoc,"CdtTrfTxInf");
        t_PmtInf.appendChild(t_CdtTrfTxInf);
        Element t_PmtId = newElement(tDoc,"PmtId");
        t_CdtTrfTxInf.appendChild(t_PmtId);
        Element t_Amt = newElement(tDoc,"Amt");
        t_CdtTrfTxInf.appendChild(t_Amt);
        Element t_CdtrAgt = newElement(tDoc,"CdtrAgt");
        t_CdtTrfTxInf.appendChild(t_CdtrAgt);
        Element t_CdtrAcct = newElement(tDoc,"CdtrAcct");
        t_CdtTrfTxInf.appendChild(t_CdtrAcct);
        Element t_RmtInf = newElement(tDoc,"RmtInf");
        t_CdtTrfTxInf.appendChild(t_RmtInf);
        Element t_InstdAmt = newElement(tDoc,"InstdAmt");
        t_Amt.appendChild(t_InstdAmt);
        Element t_FinInstnId = newElement(tDoc,"FinInstnId");
        t_CdtrAgt.appendChild(t_FinInstnId);
        Element t_Id = newElement(tDoc,"Id");
        t_CdtrAcct.appendChild(t_Id);
        Element t_Strd = newElement(tDoc,"Strd");
        t_RmtInf.appendChild(t_Strd);
        Element t_RfrdDocInf = newElement(tDoc,"RfrdDocInf");
        t_Strd.appendChild(t_RfrdDocInf);

        List<Element> stack1 = push(sRecord7,stack);

        Node sEndToEndId = namedChildNode(sRecord7,"TX_ID");
        if (sEndToEndId != null) t_PmtId.appendChild(textElement(tDoc,"EndToEndId",getText(sEndToEndId)));

        Node sCcy = namedChildNode(sRecord7,"CURRENCY");
        if (sCcy != null) t_InstdAmt.appendChild(textElement(tDoc,"Ccy",getText(sCcy)));

        Node sIBAN1 = namedChildNode(sRecord7,"CREDITOR_ACCOUNT");
        if (sIBAN1 != null) t_Id.appendChild(textElement(tDoc,"IBAN",getText(sIBAN1)));

        Node sRltdDt = namedChildNode(sRecord7,"REL_DATE");
        if (sRltdDt != null) t_RfrdDocInf.appendChild(textElement(tDoc,"RltdDt",getText(sRltdDt)));
        rFiller7(stack1, t_CdtTrfTxInf);
        rGenericAccoun1(stack1, t_Id);
        rInstructionFo(stack1, t_CdtTrfTxInf);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; 
* @param t_CdtTrfTxInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf
*/
private void rFiller7(List<Element> stack, Element t_CdtTrfTxInf) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDRESS2 : namedChildElements(sourceTop,"ADDRESS"))
    {

        List<Element> stack1 = push(sADDRESS2,stack);
        rPartyIdentifi2(stack1, t_CdtTrfTxInf);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; (7)ADDRESS; 
* @param t_CdtTrfTxInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf
*/
private void rPartyIdentifi2(List<Element> stack, Element t_CdtTrfTxInf) throws Exception
{
    Element sADDRESS2 = stack.get(7);
    Element sRecord7 = stack.get(6);
    for(Element sRecord8 : namedChildElements(sADDRESS2,"record"))
    if ( crossTest(sRecord8, "PARTY_NAME", sRecord7, "CREDITOR_NAME") &&  crossTest(sRecord8, "ADDR", sRecord7, "CREDITOR_ADDR"))
    {
        Element t_Cdtr = newElement(tDoc,"Cdtr");
        t_CdtTrfTxInf.appendChild(t_Cdtr);
        Element t_PstlAdr1 = newElement(tDoc,"PstlAdr");
        t_Cdtr.appendChild(t_PstlAdr1);

        List<Element> stack1 = push(sRecord8,stack);

        Node sNm2 = namedChildNode(sRecord8,"PARTY_NAME");
        if (sNm2 != null) t_Cdtr.appendChild(textElement(tDoc,"Nm",getText(sNm2)));

        Node sDept = namedChildNode(sRecord8,"DEPT");
        if (sDept != null) t_PstlAdr1.appendChild(textElement(tDoc,"Dept",getText(sDept)));

        Node sStrtNm2 = namedChildNode(sRecord8,"STREET");
        if (sStrtNm2 != null) t_PstlAdr1.appendChild(textElement(tDoc,"StrtNm",getText(sStrtNm2)));

        Node sBldgNb2 = namedChildNode(sRecord8,"BUILDING_NBR");
        if (sBldgNb2 != null) t_PstlAdr1.appendChild(textElement(tDoc,"BldgNb",getText(sBldgNb2)));

        Node sPstCd2 = namedChildNode(sRecord8,"POST_CODE");
        if (sPstCd2 != null) t_PstlAdr1.appendChild(textElement(tDoc,"PstCd",getText(sPstCd2)));

        Node sTwnNm2 = namedChildNode(sRecord8,"TOWN");
        if (sTwnNm2 != null) t_PstlAdr1.appendChild(textElement(tDoc,"TwnNm",getText(sTwnNm2)));

        Node sCtry2 = namedChildNode(sRecord8,"COUNTRY");
        if (sCtry2 != null) t_PstlAdr1.appendChild(textElement(tDoc,"Ctry",getText(sCtry2)));
        rFiller8(stack1, t_PstlAdr1);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; (7)ADDRESS; (8)record; 
* @param t_PstlAdr1 - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf.Cdtr.PstlAdr
*/
private void rFiller8(List<Element> stack, Element t_PstlAdr1) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sADDR2 : namedChildElements(sourceTop,"ADDR_LINES"))
    {

        List<Element> stack1 = push(sADDR2,stack);
        rMax70Text2(stack1, t_PstlAdr1);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; (7)ADDRESS; (8)record; (9)ADDR_LINES; 
* @param t_PstlAdr1 - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf.Cdtr.PstlAdr
*/
private void rMax70Text2(List<Element> stack, Element t_PstlAdr1) throws Exception
{
    Element sADDR2 = stack.get(9);
    Element sRecord8 = stack.get(8);
    for(Element sRecord9 : namedChildElements(sADDR2,"record"))
    if ( crossTest(sRecord9, "PARTY_NAME", sRecord8, "PARTY_NAME") &&  crossTest(sRecord9, "ADDR", sRecord8, "ADDR"))
    {
        Element t_AdrLine1 = newElement(tDoc,"AdrLine");
        t_PstlAdr1.appendChild(t_AdrLine1);

        List<Element> stack1 = push(sRecord9,stack);

        Node sTextValue2 = namedChildNode(sRecord9,"ADDRESS");
        if (sTextValue2 != null) t_AdrLine1.appendChild(textElement(tDoc,"textValue",getText(sTextValue2)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; 
* @param t_Id - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf.CdtrAcct.Id
*/
private void rGenericAccoun1(List<Element> stack, Element t_Id) throws Exception
{
    Element sRecord7 = stack.get(6);
    Element sRecord10 = sRecord7;
    if (valueTest(sRecord10,"CREDITOR_IBAN", "N","="))
    {
        Element t_Othr = newElement(tDoc,"Othr");
        t_Id.appendChild(t_Othr);

        List<Element> stack1 = push(sRecord10,stack);

        Node sId1 = namedChildNode(sRecord10,"CREDITOR_ACCOUNT");
        if (sId1 != null) t_Othr.appendChild(textElement(tDoc,"Id",getText(sId1)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)CREDIT_TX; (6)record; 
* @param t_CdtTrfTxInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf.CdtTrfTxInf
*/
private void rInstructionFo(List<Element> stack, Element t_CdtTrfTxInf) throws Exception
{
    Element sRecord7 = stack.get(6);
    Element sRecord11 = sRecord7;
    if (valueTest(sRecord11,"CURRENCY", "EUR","="))
    {
        Element t_InstrForCdtr = newElement(tDoc,"InstrForCdtrAgt");
        t_CdtTrfTxInf.appendChild(t_InstrForCdtr);
        t_InstrForCdtr.appendChild(textElement(tDoc,"InstrInf",("+32/2/2222222")));

        List<Element> stack1 = push(sRecord11,stack);

        Node sCd = namedChildNode(sRecord11,"INST_CREDITOR_AGENT");
        if (sCd != null) t_InstrForCdtr.appendChild(textElement(tDoc,"Cd",getText(sCd)));
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; 
* @param t_PmtInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
private void rFiller9(List<Element> stack, Element t_PmtInf) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sBANK : namedChildElements(sourceTop,"BANK"))
    {

        List<Element> stack1 = push(sBANK,stack);
        rBranchAndFina(stack1, t_PmtInf);
    }
}

/**
* @param stack - source elements (0)database; (1)GROUP_HEADER; (2)record; (3)PAYMENT_INST; (4)record; (5)BANK; 
* @param t_PmtInf - reached by target path: Batch.Document.CstmrCdtTrfInitn.PmtInf
*/
private void rBranchAndFina(List<Element> stack, Element t_PmtInf) throws Exception
{
    Element sBANK = stack.get(5);
    Element sRecord3 = stack.get(4);
    for(Element sRecord12 : namedChildElements(sBANK,"record"))
    if ( crossTest(sRecord12, "PARTY_NAME", sRecord3, "DEBTOR_NAME") && valueTest(sRecord12,"BANK", "01","="))
    {
        Element t_DbtrAgt = newElement(tDoc,"DbtrAgt");
        t_PmtInf.appendChild(t_DbtrAgt);
        Element t_FinInstnId1 = newElement(tDoc,"FinInstnId");
        t_DbtrAgt.appendChild(t_FinInstnId1);

        List<Element> stack1 = push(sRecord12,stack);

        Node sBICFI = namedChildNode(sRecord12,"BIC");
        if (sBICFI != null) t_FinInstnId1.appendChild(textElement(tDoc,"BICFI",getText(sBICFI)));
    }
}
}
