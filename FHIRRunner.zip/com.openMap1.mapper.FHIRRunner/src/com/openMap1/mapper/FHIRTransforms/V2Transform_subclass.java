package com.openMap1.mapper.FHIRTransforms;

import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import ca.uhn.fhir.model.dstu2.composite.HumanNameDt;
import ca.uhn.fhir.model.dstu2.resource.Patient;
import ca.uhn.fhir.model.primitive.StringDt;

public class V2Transform_subclass extends V2Transform{
	
	/**
	* @param stack - source elements (0)ADT_A05; (1)PID; 
	* @param t_resource - reached by target path: Bundle.entry.resource
	*/
	protected void rHumanName(List<Element> stack, Patient t_resource) throws Exception
	{
		System.out.println("Subclass overriding");
	    Element sPID = stack.get(1);
	    for(Element sPID2 : namedChildElements(sPID,"PID.5"))
	    {
	        HumanNameDt t_name = new HumanNameDt(); 
	        t_resource.addName(t_name);

	        List<Element> stack1 = push(sPID2,stack);

	        Node sXPN = namedChildNode(sPID2,"XPN.2");
	        if (sXPN != null) t_name.getGiven().add(new StringDt(getText(sXPN)));

	        Node sXPN1 = namedChildNode(sPID2,"XPN.1");
	        if (sXPN1 != null) t_name.getFamily().add(new StringDt(getText(sXPN1)));
	    }
	}


}
