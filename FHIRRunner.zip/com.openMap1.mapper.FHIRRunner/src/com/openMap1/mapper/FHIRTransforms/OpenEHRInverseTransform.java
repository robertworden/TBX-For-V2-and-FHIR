package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;


public class OpenEHRInverseTransform extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Mon Oct 16 16:31:10 BST 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}

// Document for transform result
private Document tDoc;


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public Element transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   tDoc = makeOutDoc();
   return topRule(root);
}

/**
* @param sourceTop
*/
protected Element topRule(Element sourceTop) throws Exception
{
    if (!("Bundle".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'Bundle'");
    Element target = newElement(tDoc,"composition");
    tDoc.appendChild(target);
    target.setAttribute("xmlns:xs","http://www.w3.org/2001/XMLSchema");
    target.setAttribute("xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance");
    target.setAttribute("xmlns","http://schemas.openehr.org/v1");
    addFixedValue(target,"archetype_details/archetype_id/value","openEHR-EHR-COMPOSITION.adverse_reaction_list.v1");
    addFixedValue(target,"@archetype_node_id","openEHR-EHR-COMPOSITION.adverse_reaction_list.v1");
    addFixedValue(target,"@xsi:type","COMPOSITION");
    addFixedValue(target,"name/value","Adverse reaction list");

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rFiller(stack1, target);
    return target;
}

/**
* @param stack - source elements (0)Bundle; 
* @param target - reached by target path: composition
*/
protected void rFiller(List<Element> stack, Element target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sEntry : namedChildElements(sourceTop,"entry"))
    if (valueTest(sEntry,"resource/AllergyIntolerance", "AllergyIntolerance","contains"))
    {

        List<Element> stack1 = push(sEntry,stack);
        rFiller1(stack1, target);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; 
* @param target - reached by target path: composition
*/
protected void rFiller1(List<Element> stack, Element target) throws Exception
{
    Element sEntry = stack.get(1);
    for(Element sResource : namedChildElements(sEntry,"resource"))
    {

        List<Element> stack1 = push(sResource,stack);
        rFiller2(stack1, target);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; 
* @param target - reached by target path: composition
*/
protected void rFiller2(List<Element> stack, Element target) throws Exception
{
    Element sResource = stack.get(2);
    for(Element sAllergyIntole : namedChildElements(sResource,"AllergyIntolerance"))
    {

        List<Element> stack1 = push(sAllergyIntole,stack);
        rSECTION(stack1, target);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; (3)AllergyIntolerance; 
* @param target - reached by target path: composition
*/
protected void rSECTION(List<Element> stack, Element target) throws Exception
{
    Element sAllergyIntole = stack.get(3);
    for(Element sReaction : namedChildElements(sAllergyIntole,"reaction"))
    {
        Element t_content_at00 = newElement(tDoc,"content");
        target.appendChild(t_content_at00);
        addFixedValue(t_content_at00,"archetype_details/archetype_id/value","openEHR-EHR-SECTION.allergies_adverse_reactions_rcp.v1");
        addFixedValue(t_content_at00,"@archetype_node_id","openEHR-EHR-SECTION.allergies_adverse_reactions_rcp.v1");
        addFixedValue(t_content_at00,"@xsi:type","SECTION");
        addFixedValue(t_content_at00,"name/value","Allergies and adverse reactions");
        t_content_at00.setAttribute("archetype_node_id","openEHR-EHR-SECTION.allergies_adverse_reactions_rcp.v1");
        Element t_items_at0000 = newElement(tDoc,"items");
        t_content_at00.appendChild(t_items_at0000);
        addFixedValue(t_items_at0000,"archetype_details/archetype_id/value","openEHR-EHR-EVALUATION.adverse_reaction_risk.v1");
        addFixedValue(t_items_at0000,"@archetype_node_id","openEHR-EHR-EVALUATION.adverse_reaction_risk.v1");
        addFixedValue(t_items_at0000,"@xsi:type","EVALUATION");
        addFixedValue(t_items_at0000,"name/value","Adverse reaction risk");
        t_items_at0000.setAttribute("archetype_node_id","openEHR-EHR-EVALUATION.adverse_reaction_risk.v1");
        Element t_data_at0001_ = newElement(tDoc,"data");
        t_items_at0000.appendChild(t_data_at0001_);
        addFixedValue(t_data_at0001_,"@archetype_node_id","at0001");
        addFixedValue(t_data_at0001_,"@xsi:type","ITEM_TREE");
        addFixedValue(t_data_at0001_,"name/value","Tree");
        t_data_at0001_.setAttribute("archetype_node_id","at0001");

        List<Element> stack1 = push(sReaction,stack);
        rFiller3(stack1, t_data_at0001_);
        rFiller5(stack1, t_data_at0001_);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; (3)AllergyIntolerance; (4)reaction; 
* @param t_data_at0001_ - reached by target path: composition.content.items.data
*/
protected void rFiller3(List<Element> stack, Element t_data_at0001_) throws Exception
{
    Element sReaction = stack.get(4);
    for(Element sManifestation : namedChildElements(sReaction,"manifestation"))
    {

        List<Element> stack1 = push(sManifestation,stack);
        rFiller4(stack1, t_data_at0001_);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; (3)AllergyIntolerance; (4)reaction; (5)manifestation; 
* @param t_data_at0001_ - reached by target path: composition.content.items.data
*/
protected void rFiller4(List<Element> stack, Element t_data_at0001_) throws Exception
{
    Element sManifestation = stack.get(5);
    for(Element sCoding : namedChildElements(sManifestation,"coding"))
    {

        List<Element> stack1 = push(sCoding,stack);
        rCLUSTER(stack1, t_data_at0001_);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; (3)AllergyIntolerance; (4)reaction; (5)manifestation; (6)coding; 
* @param t_data_at0001_ - reached by target path: composition.content.items.data
*/
protected void rCLUSTER(List<Element> stack, Element t_data_at0001_) throws Exception
{
    Element sCoding = stack.get(6);
    for(Element sDisplay : namedChildElements(sCoding,"display"))
    {
        Element t_items_at0009 = newElement(tDoc,"items");
        t_data_at0001_.appendChild(t_items_at0009);
        addFixedValue(t_items_at0009,"@archetype_node_id","at0128");
        addFixedValue(t_items_at0009,"@xsi:type","CLUSTER");
        addFixedValue(t_items_at0009,"name/value","Extension");
        t_items_at0009.setAttribute("archetype_node_id","at0009");
        Element t_items_at0011 = newElement(tDoc,"items");
        t_items_at0009.appendChild(t_items_at0011);
        t_items_at0011.setAttribute("archetype_node_id","at0011");
        Element t_value = newElement(tDoc,"value");
        t_items_at0011.appendChild(t_value);
        t_value.setAttribute("xsi:type","DV_TEXT");

        List<Element> stack1 = push(sDisplay,stack);

        Node sValue = namedChildNode(sDisplay,"value");
        if (sValue != null) t_value.appendChild(textElement(tDoc,"value",getText(sValue)));
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; (3)AllergyIntolerance; (4)reaction; 
* @param t_data_at0001_ - reached by target path: composition.content.items.data
*/
protected void rFiller5(List<Element> stack, Element t_data_at0001_) throws Exception
{
    Element sReaction = stack.get(4);
    for(Element sSubstance : namedChildElements(sReaction,"substance"))
    {

        List<Element> stack1 = push(sSubstance,stack);
        rFiller6(stack1, t_data_at0001_);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; (3)AllergyIntolerance; (4)reaction; (5)substance; 
* @param t_data_at0001_ - reached by target path: composition.content.items.data
*/
protected void rFiller6(List<Element> stack, Element t_data_at0001_) throws Exception
{
    Element sSubstance = stack.get(5);
    for(Element sCoding1 : namedChildElements(sSubstance,"coding"))
    {

        List<Element> stack1 = push(sCoding1,stack);
        rELEMENT(stack1, t_data_at0001_);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_AllergyIntolerance; (2)resource; (3)AllergyIntolerance; (4)reaction; (5)substance; (6)coding; 
* @param t_data_at0001_ - reached by target path: composition.content.items.data
*/
protected void rELEMENT(List<Element> stack, Element t_data_at0001_) throws Exception
{
    Element sCoding1 = stack.get(6);
    for(Element sDisplay1 : namedChildElements(sCoding1,"display"))
    {
        Element t_items_at0002 = newElement(tDoc,"items");
        t_data_at0001_.appendChild(t_items_at0002);
        addFixedValue(t_items_at0002,"@archetype_node_id","at0128");
        addFixedValue(t_items_at0002,"@xsi:type","CLUSTER");
        addFixedValue(t_items_at0002,"name/value","Extension");
        t_items_at0002.setAttribute("archetype_node_id","at0002");
        Element t_value1 = newElement(tDoc,"value");
        t_items_at0002.appendChild(t_value1);
        t_value1.setAttribute("xsi:type","DV_CODED_TEXT");

        List<Element> stack1 = push(sDisplay1,stack);

        Node sValue1 = namedChildNode(sDisplay1,"value");
        if (sValue1 != null) t_value1.appendChild(textElement(tDoc,"value",getText(sValue1)));
    }
}
}
