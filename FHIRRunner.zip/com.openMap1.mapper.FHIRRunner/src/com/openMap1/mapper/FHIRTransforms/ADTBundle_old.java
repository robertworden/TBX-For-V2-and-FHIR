package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import ca.uhn.fhir.model.primitive.*;
import ca.uhn.fhir.model.dstu2.resource.BaseResource;

import ca.uhn.fhir.model.dstu2.resource.Patient.Contact;
import ca.uhn.fhir.model.dstu2.resource.Practitioner;
import ca.uhn.fhir.model.dstu2.resource.Location;
import ca.uhn.fhir.model.dstu2.composite.ContactPointDt;
import ca.uhn.fhir.model.dstu2.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu2.resource.Patient.Communication;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.resource.Patient;
import ca.uhn.fhir.model.dstu2.composite.HumanNameDt;
import ca.uhn.fhir.model.dstu2.resource.MessageHeader;
import ca.uhn.fhir.model.dstu2.resource.Encounter;
import ca.uhn.fhir.model.dstu2.valueset.AddressUseEnum;
import ca.uhn.fhir.model.dstu2.resource.Encounter.Hospitalization;
import ca.uhn.fhir.model.dstu2.resource.Organization;
import ca.uhn.fhir.model.dstu2.resource.MessageHeader.Source;
import ca.uhn.fhir.model.dstu2.composite.CodingDt;
import ca.uhn.fhir.model.dstu2.composite.IdentifierDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle;
import ca.uhn.fhir.model.dstu2.composite.AddressDt;

public class ADTBundle_old extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Fri Nov 10 19:54:32 GMT 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public BaseResource transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   return topRule(root);
}

/**
* @param sourceTop
*/
protected BaseResource topRule(Element sourceTop) throws Exception
{
    if (!("ADT_A05".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'ADT_A05'");
    Bundle target = new Bundle();
    Bundle.Entry t_entry_Patien = new Bundle.Entry(); 
    target.addEntry(t_entry_Patien);
    Bundle.Entry t_entry_Encoun = new Bundle.Entry(); 
    target.addEntry(t_entry_Encoun);
    Patient t_resource9 = new Patient();
    t_entry_Patien.setResource(t_resource9);
    Encounter t_resource10 = new Encounter();
    t_entry_Encoun.setResource(t_resource10);
    Patient.Contact t_contact = new Patient.Contact(); 
    t_resource9.addContact(t_contact);
    HumanNameDt t_name5 = new HumanNameDt(); 
    t_contact.setName(t_name5);

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rFiller(stack1, t_resource9);
    rFiller1(stack1, t_resource9);
    rBundle_Entry_(stack1, target);
    rFiller4(stack1, t_resource9);
    rFiller6(stack1, target);
    rFiller8(stack1, target);
    rFiller10(stack1, t_name5);
    rFiller12(stack1, target);
    rFiller14(stack1, target);
    rFiller16(stack1, target);
    rFiller18(stack1, target);
    rFiller20(stack1, t_contact);
    rFiller22(stack1, t_resource9);
    rFiller24(stack1, target);
    rFiller25(stack1, t_resource9);
    rFiller26(stack1, t_resource10);
    rFiller27(stack1, t_resource9);
    rFiller28(stack1, target);
    rFiller30(stack1, t_contact);
    rFiller32(stack1, t_resource9);
    rFiller34(stack1, t_resource10);
    rFiller36(stack1, t_resource9);
    rFiller38(stack1, t_name5);
    rFiller40(stack1, t_resource9);
    rFiller42(stack1, t_contact);
    rCodeableConce2(stack1, t_resource10);
    rFiller43(stack1, t_resource9);
    rHumanName3(stack1, t_resource9);
    return target;
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID,stack);
        rHumanName(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rHumanName(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID = stack.get(1);
    for(Element sPID1 : namedChildElements(sPID,"PID.5"))
    if (valueTest(sPID1,"XPN.1", "MIAH","="))
    {
        HumanNameDt t_name1 = new HumanNameDt(); 
        t_resource9.addName(t_name1);

        List<Element> stack1 = push(sPID1,stack);

        Node sXPN = namedChildNode(sPID1,"XPN.5");
        if (sXPN != null) t_name1.getPrefix().add(new StringDt(getText(sXPN)));

        Node sXPN1 = namedChildNode(sPID1,"XPN.2");
        if (sXPN1 != null) t_name1.getGiven().add(new StringDt(getText(sXPN1)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller1(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID2 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID2,stack);
        rFiller2(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller2(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID2 = stack.get(1);
    for(Element sPID3 : namedChildElements(sPID2,"PID.2"))
    {

        List<Element> stack1 = push(sPID3,stack);
        rIdentifier(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_2; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID3 = stack.get(2);
    for(Element sCX : namedChildElements(sPID3,"CX.1"))
    {
        IdentifierDt t_identifier2 = new IdentifierDt(); 
        t_resource9.addIdentifier(t_identifier2);
        t_identifier2.setValue(getText(sCX));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sMSH : namedChildElements(sourceTop,"MSH"))
    {
        Bundle.Entry t_entry_Messag = new Bundle.Entry(); 
        target.addEntry(t_entry_Messag);
        MessageHeader t_resource = new MessageHeader();
        t_entry_Messag.setResource(t_resource);
        MessageHeader.Source t_source = new MessageHeader.Source(); 
        t_resource.setSource(t_source);

        List<Element> stack1 = push(sMSH,stack);
        pFiller(stack1, t_source);
        pFiller1(stack1, t_source);
        rFiller3(stack1, t_resource);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)MSH; 
* @param t_source - reached by target path: Bundle.entry.resource.source
*/
protected void pFiller(List<Element> stack, MessageHeader.Source t_source) throws Exception
{
    Element sMSH = stack.get(1);
    for(Element sMSH1 : namedChildElements(sMSH,"MSH.3"))
    {

        List<Element> stack1 = push(sMSH1,stack);

        Node sSoftware = namedChildNode(sMSH1,"HD.1");
        if (sSoftware != null) t_source.setSoftware(getText(sSoftware));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)MSH; 
* @param t_source - reached by target path: Bundle.entry.resource.source
*/
protected void pFiller1(List<Element> stack, MessageHeader.Source t_source) throws Exception
{
    Element sMSH = stack.get(1);
    for(Element sMSH2 : namedChildElements(sMSH,"MSH.6"))
    {

        List<Element> stack1 = push(sMSH2,stack);

        Node sName = namedChildNode(sMSH2,"HD.1");
        if (sName != null) t_source.setName(getText(sName));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)MSH; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
protected void rFiller3(List<Element> stack, MessageHeader t_resource) throws Exception
{
    Element sMSH = stack.get(1);
    for(Element sMSH3 : namedChildElements(sMSH,"MSH.12"))
    {

        List<Element> stack1 = push(sMSH3,stack);
        rCoding(stack1, t_resource);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)MSH; (2)MSH_12; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
protected void rCoding(List<Element> stack, MessageHeader t_resource) throws Exception
{
    Element sMSH3 = stack.get(2);
    for(Element sVID : namedChildElements(sMSH3,"VID.1"))
    {
        CodingDt t_event = new CodingDt(); 
        t_resource.setEvent(t_event);
        t_event.setVersion(getText(sVID));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller4(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID4 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID4,stack);
        rFiller5(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller5(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID4 = stack.get(1);
    for(Element sPID5 : namedChildElements(sPID4,"PID.11"))
    {

        List<Element> stack1 = push(sPID5,stack);
        rAddress(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_11; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rAddress(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID5 = stack.get(2);
    for(Element sXAD : namedChildElements(sPID5,"XAD.4"))
    if (valueTest(sXAD,"ancestor::PID.11/XAD.1", "Flat 1","="))
    {
        AddressDt t_address2 = new AddressDt(); 
        t_resource9.addAddress(t_address2);
        t_address2.setDistrict(getText(sXAD));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller6(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID6 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID6,stack);
        rFiller7(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param target - reached by target path: Bundle
*/
protected void rFiller7(List<Element> stack, Bundle target) throws Exception
{
    Element sPID6 = stack.get(1);
    for(Element sPID7 : namedChildElements(sPID6,"PID.11"))
    {

        List<Element> stack1 = push(sPID7,stack);
        rBundle_Entry_1(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_11; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_1(List<Element> stack, Bundle target) throws Exception
{
    Element sPID7 = stack.get(2);
    for(Element sXAD1 : namedChildElements(sPID7,"XAD.4"))
    if (valueTest(sXAD1,"ancestor::PID.11/XAD.1", "Flat 1","="))
    {
        Bundle.Entry t_entry_Organi = new Bundle.Entry(); 
        target.addEntry(t_entry_Organi);
        Organization t_resource1 = new Organization();
        t_entry_Organi.setResource(t_resource1);
        AddressDt t_address = new AddressDt(); 
        t_resource1.addAddress(t_address);
        t_address.setCity(getText(sXAD1));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller8(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID8 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID8,stack);
        rFiller9(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param target - reached by target path: Bundle
*/
protected void rFiller9(List<Element> stack, Bundle target) throws Exception
{
    Element sPID8 = stack.get(1);
    for(Element sPID9 : namedChildElements(sPID8,"PID.11"))
    {

        List<Element> stack1 = push(sPID9,stack);
        rBundle_Entry_2(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_11; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_2(List<Element> stack, Bundle target) throws Exception
{
    Element sPID9 = stack.get(2);
    for(Element sXAD2 : namedChildElements(sPID9,"XAD.4"))
    if (valueTest(sXAD2,"ancestor::PID.11/XAD.1", "Flat 1","="))
    {
        Bundle.Entry t_entry_Locati = new Bundle.Entry(); 
        target.addEntry(t_entry_Locati);
        Location t_resource2 = new Location();
        t_entry_Locati.setResource(t_resource2);
        AddressDt t_address1 = new AddressDt(); 
        t_resource2.setAddress(t_address1);
        t_address1.setCity(getText(sXAD2));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_name5 - reached by target path: Bundle.entry.resource.contact.name
*/
protected void rFiller10(List<Element> stack, HumanNameDt t_name5) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK1 : namedChildElements(sourceTop,"NK1"))
    {

        List<Element> stack1 = push(sNK1,stack);
        rFiller11(stack1, t_name5);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)NK1; 
* @param t_name5 - reached by target path: Bundle.entry.resource.contact.name
*/
protected void rFiller11(List<Element> stack, HumanNameDt t_name5) throws Exception
{
    Element sNK1 = stack.get(1);
    for(Element sNK11 : namedChildElements(sNK1,"NK1.2"))
    {

        List<Element> stack1 = push(sNK11,stack);

        Node sXPN2 = namedChildNode(sNK11,"XPN.2");
        if (sXPN2 != null) t_name5.getGiven().add(new StringDt(getText(sXPN2)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller12(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV1 : namedChildElements(sourceTop,"PV1"))
    {

        List<Element> stack1 = push(sPV1,stack);
        rFiller13(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; 
* @param target - reached by target path: Bundle
*/
protected void rFiller13(List<Element> stack, Bundle target) throws Exception
{
    Element sPV1 = stack.get(1);
    for(Element sPV11 : namedChildElements(sPV1,"PV1.3"))
    {

        List<Element> stack1 = push(sPV11,stack);
        rBundle_Entry_3(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; (2)PV1_3; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_3(List<Element> stack, Bundle target) throws Exception
{
    Element sPV11 = stack.get(2);
    for(Element sPL : namedChildElements(sPV11,"PL.3"))
    {
        Bundle.Entry t_entry_Locati1 = new Bundle.Entry(); 
        target.addEntry(t_entry_Locati1);
        Location t_resource3 = new Location();
        t_entry_Locati1.setResource(t_resource3);
        t_resource3.setName(getText(sPL));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller14(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV12 : namedChildElements(sourceTop,"PV1"))
    {

        List<Element> stack1 = push(sPV12,stack);
        rFiller15(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; 
* @param target - reached by target path: Bundle
*/
protected void rFiller15(List<Element> stack, Bundle target) throws Exception
{
    Element sPV12 = stack.get(1);
    for(Element sPV13 : namedChildElements(sPV12,"PV1.3"))
    {

        List<Element> stack1 = push(sPV13,stack);
        rBundle_Entry_4(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; (2)PV1_3; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_4(List<Element> stack, Bundle target) throws Exception
{
    Element sPV13 = stack.get(2);
    for(Element sPL1 : namedChildElements(sPV13,"PL.2"))
    {
        Bundle.Entry t_entry_Locati2 = new Bundle.Entry(); 
        target.addEntry(t_entry_Locati2);
        Location t_resource4 = new Location();
        t_entry_Locati2.setResource(t_resource4);
        t_resource4.setName(getText(sPL1));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller16(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV14 : namedChildElements(sourceTop,"PV1"))
    {

        List<Element> stack1 = push(sPV14,stack);
        rFiller17(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; 
* @param target - reached by target path: Bundle
*/
protected void rFiller17(List<Element> stack, Bundle target) throws Exception
{
    Element sPV14 = stack.get(1);
    for(Element sPV15 : namedChildElements(sPV14,"PV1.3"))
    {

        List<Element> stack1 = push(sPV15,stack);
        rBundle_Entry_5(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; (2)PV1_3; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_5(List<Element> stack, Bundle target) throws Exception
{
    Element sPV15 = stack.get(2);
    for(Element sPL2 : namedChildElements(sPV15,"PL.1"))
    {
        Bundle.Entry t_entry_Locati3 = new Bundle.Entry(); 
        target.addEntry(t_entry_Locati3);
        Location t_resource5 = new Location();
        t_entry_Locati3.setResource(t_resource5);
        t_resource5.setName(getText(sPL2));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller18(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPD1 : namedChildElements(sourceTop,"PD1"))
    {

        List<Element> stack1 = push(sPD1,stack);
        rFiller19(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PD1; 
* @param target - reached by target path: Bundle
*/
protected void rFiller19(List<Element> stack, Bundle target) throws Exception
{
    Element sPD1 = stack.get(1);
    for(Element sPD11 : namedChildElements(sPD1,"PD1.4"))
    {

        List<Element> stack1 = push(sPD11,stack);
        rBundle_Entry_6(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PD1; (2)PD1_4; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_6(List<Element> stack, Bundle target) throws Exception
{
    Element sPD11 = stack.get(2);
    for(Element sXCN : namedChildElements(sPD11,"XCN.1"))
    {
        Bundle.Entry t_entry_Practi = new Bundle.Entry(); 
        target.addEntry(t_entry_Practi);
        Practitioner t_resource6 = new Practitioner();
        t_entry_Practi.setResource(t_resource6);
        IdentifierDt t_identifier = new IdentifierDt(); 
        t_resource6.addIdentifier(t_identifier);
        t_identifier.setValue(getText(sXCN));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rFiller20(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK12 : namedChildElements(sourceTop,"NK1"))
    {

        List<Element> stack1 = push(sNK12,stack);
        rFiller21(stack1, t_contact);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)NK1; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rFiller21(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sNK12 = stack.get(1);
    for(Element sNK13 : namedChildElements(sNK12,"NK1.7"))
    {

        List<Element> stack1 = push(sNK13,stack);
        rCodeableConce(stack1, t_contact);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)NK1; (2)NK1_7; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rCodeableConce(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sNK13 = stack.get(2);
    for(Element sCE : namedChildElements(sNK13,"CE.1"))
    {
        CodeableConceptDt t_relationship = new CodeableConceptDt(); 
        t_contact.addRelationship(t_relationship);
        t_relationship.setText(getText(sCE));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller22(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID10 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID10,stack);
        rFiller23(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller23(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID10 = stack.get(1);
    for(Element sPID11 : namedChildElements(sPID10,"PID.3"))
    {

        List<Element> stack1 = push(sPID11,stack);
        rIdentifier1(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_3; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier1(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID11 = stack.get(2);
    for(Element sCX1 : namedChildElements(sPID11,"CX.1"))
    {
        IdentifierDt t_identifier3 = new IdentifierDt(); 
        t_resource9.addIdentifier(t_identifier3);
        t_identifier3.setValue(getText(sCX1));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller24(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sEVN : namedChildElements(sourceTop,"EVN"))
    {

        List<Element> stack1 = push(sEVN,stack);
        rBundle_Entry_7(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)EVN; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_7(List<Element> stack, Bundle target) throws Exception
{
    Element sEVN = stack.get(1);
    for(Element sEVN1 : namedChildElements(sEVN,"EVN.5"))
    {
        Bundle.Entry t_entry_Practi1 = new Bundle.Entry(); 
        target.addEntry(t_entry_Practi1);
        Practitioner t_resource7 = new Practitioner();
        t_entry_Practi1.setResource(t_resource7);
        HumanNameDt t_name = new HumanNameDt(); 
        t_resource7.setName(t_name);

        List<Element> stack1 = push(sEVN1,stack);

        Node sXCN1 = namedChildNode(sEVN1,"XCN.3");
        if (sXCN1 != null) t_name.getGiven().add(new StringDt(getText(sXCN1)));

        Node sXCN2 = namedChildNode(sEVN1,"XCN.2");
        if (sXCN2 != null) t_name.getFamily().add(new StringDt(getText(sXCN2)));
        rIdentifier2(stack1, t_resource7);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)EVN; (2)EVN_5; 
* @param t_resource7 - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier2(List<Element> stack, Practitioner t_resource7) throws Exception
{
    Element sEVN1 = stack.get(2);
    for(Element sXCN3 : namedChildElements(sEVN1,"XCN.1"))
    {
        IdentifierDt t_identifier1 = new IdentifierDt(); 
        t_resource7.addIdentifier(t_identifier1);
        t_identifier1.setValue(getText(sXCN3));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller25(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID12 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID12,stack);
        rIdentifier3(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier3(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID12 = stack.get(1);
    for(Element sPID13 : namedChildElements(sPID12,"PID.19"))
    {
        IdentifierDt t_identifier4 = new IdentifierDt(); 
        t_resource9.addIdentifier(t_identifier4);
        t_identifier4.setValue(getText(sPID13));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource10 - reached by target path: Bundle.entry.resource
*/
protected void rFiller26(List<Element> stack, Encounter t_resource10) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV16 : namedChildElements(sourceTop,"PV1"))
    {

        List<Element> stack1 = push(sPV16,stack);
        rEncounter_Hos(stack1, t_resource10);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; 
* @param t_resource10 - reached by target path: Bundle.entry.resource
*/
protected void rEncounter_Hos(List<Element> stack, Encounter t_resource10) throws Exception
{
    Element sPV16 = stack.get(1);
    for(Element sPV17 : namedChildElements(sPV16,"PV1.36"))
    {
        Encounter.Hospitalization t_hospitalizat = new Encounter.Hospitalization(); 
        t_resource10.setHospitalization(t_hospitalizat);
        CodeableConceptDt t_dischargeDis = new CodeableConceptDt(); 
        t_hospitalizat.setDischargeDisposition(t_dischargeDis);
        t_dischargeDis.setText(getText(sPV17));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller27(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID14 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID14,stack);
        rAddress1(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rAddress1(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID14 = stack.get(1);
    for(Element sPID15 : namedChildElements(sPID14,"PID.11"))
    if (valueTest(sPID15,"XAD.1", "Flat 1","="))
    {
        AddressDt t_address3 = new AddressDt(); 
        t_resource9.addAddress(t_address3);

        List<Element> stack1 = push(sPID15,stack);

        Node sDistrict = namedChildNode(sPID15,"XAD.4");
        if (sDistrict != null) t_address3.setDistrict(getText(sDistrict));

        Node sPostalCode = namedChildNode(sPID15,"XAD.5");
        if (sPostalCode != null) t_address3.setPostalCode(getText(sPostalCode));

        Node sUse = namedChildNode(sPID15,"XAD.7");
        if (sUse != null) t_address3.setUse(AddressUseEnum.forCode(getText(sUse)));

        Node sXAD3 = namedChildNode(sPID15,"XAD.2");
        if (sXAD3 != null) t_address3.getLine().add(new StringDt(getText(sXAD3)));

        Node sXAD4 = namedChildNode(sPID15,"XAD.1");
        if (sXAD4 != null) t_address3.getLine().add(new StringDt(getText(sXAD4)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rFiller28(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV18 : namedChildElements(sourceTop,"PV1"))
    {

        List<Element> stack1 = push(sPV18,stack);
        rFiller29(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; 
* @param target - reached by target path: Bundle
*/
protected void rFiller29(List<Element> stack, Bundle target) throws Exception
{
    Element sPV18 = stack.get(1);
    for(Element sPV19 : namedChildElements(sPV18,"PV1.6"))
    {

        List<Element> stack1 = push(sPV19,stack);
        rBundle_Entry_8(stack1, target);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; (2)PV1_6; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_8(List<Element> stack, Bundle target) throws Exception
{
    Element sPV19 = stack.get(2);
    for(Element sPL3 : namedChildElements(sPV19,"PL.1"))
    {
        Bundle.Entry t_entry_Locati4 = new Bundle.Entry(); 
        target.addEntry(t_entry_Locati4);
        Location t_resource8 = new Location();
        t_entry_Locati4.setResource(t_resource8);
        t_resource8.setName(getText(sPL3));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rFiller30(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK14 : namedChildElements(sourceTop,"NK1"))
    {

        List<Element> stack1 = push(sNK14,stack);
        rFiller31(stack1, t_contact);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)NK1; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rFiller31(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sNK14 = stack.get(1);
    for(Element sNK15 : namedChildElements(sNK14,"NK1.5"))
    {

        List<Element> stack1 = push(sNK15,stack);
        rContactPoint(stack1, t_contact);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)NK1; (2)NK1_5; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rContactPoint(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sNK15 = stack.get(2);
    for(Element sXTN : namedChildElements(sNK15,"XTN.1"))
    {
        ContactPointDt t_telecom1 = new ContactPointDt(); 
        t_contact.addTelecom(t_telecom1);
        t_telecom1.setValue(getText(sXTN));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller32(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID16 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID16,stack);
        rFiller33(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller33(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID16 = stack.get(1);
    for(Element sPID17 : namedChildElements(sPID16,"PID.13"))
    {

        List<Element> stack1 = push(sPID17,stack);
        rContactPoint1(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_13; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rContactPoint1(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID17 = stack.get(2);
    for(Element sXTN1 : namedChildElements(sPID17,"XTN.1"))
    {
        ContactPointDt t_telecom = new ContactPointDt(); 
        t_resource9.addTelecom(t_telecom);
        t_telecom.setValue(getText(sXTN1));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource10 - reached by target path: Bundle.entry.resource
*/
protected void rFiller34(List<Element> stack, Encounter t_resource10) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV2 : namedChildElements(sourceTop,"PV2"))
    {

        List<Element> stack1 = push(sPV2,stack);
        rFiller35(stack1, t_resource10);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV2; 
* @param t_resource10 - reached by target path: Bundle.entry.resource
*/
protected void rFiller35(List<Element> stack, Encounter t_resource10) throws Exception
{
    Element sPV2 = stack.get(1);
    for(Element sPV21 : namedChildElements(sPV2,"PV2.4"))
    {

        List<Element> stack1 = push(sPV21,stack);
        rCodeableConce1(stack1, t_resource10);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV2; (2)PV2_4; 
* @param t_resource10 - reached by target path: Bundle.entry.resource
*/
protected void rCodeableConce1(List<Element> stack, Encounter t_resource10) throws Exception
{
    Element sPV21 = stack.get(2);
    for(Element sCE1 : namedChildElements(sPV21,"CE.1"))
    {
        CodeableConceptDt t_reason = new CodeableConceptDt(); 
        t_resource10.addReason(t_reason);
        t_reason.setText(getText(sCE1));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller36(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID18 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID18,stack);
        rFiller37(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller37(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID18 = stack.get(1);
    for(Element sPID19 : namedChildElements(sPID18,"PID.9"))
    {

        List<Element> stack1 = push(sPID19,stack);
        rHumanName1(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_9; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rHumanName1(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID19 = stack.get(2);
    for(Element sXPN3 : namedChildElements(sPID19,"XPN.1"))
    if (valueTest(sXPN3,"ancestor::PID.9/XPN.2", "Janet","="))
    {
        HumanNameDt t_name2 = new HumanNameDt(); 
        t_resource9.addName(t_name2);
        t_name2.getGiven().add(new StringDt(getText(sXPN3)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_name5 - reached by target path: Bundle.entry.resource.contact.name
*/
protected void rFiller38(List<Element> stack, HumanNameDt t_name5) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID20 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID20,stack);
        rFiller39(stack1, t_name5);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_name5 - reached by target path: Bundle.entry.resource.contact.name
*/
protected void rFiller39(List<Element> stack, HumanNameDt t_name5) throws Exception
{
    Element sPID20 = stack.get(1);
    for(Element sPID21 : namedChildElements(sPID20,"PID.9"))
    {

        List<Element> stack1 = push(sPID21,stack);

        Node sXPN4 = namedChildNode(sPID21,"XPN.1");
        if (sXPN4 != null) t_name5.getFamily().add(new StringDt(getText(sXPN4)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller40(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID22 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID22,stack);
        rFiller41(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller41(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID22 = stack.get(1);
    for(Element sPID23 : namedChildElements(sPID22,"PID.15"))
    {

        List<Element> stack1 = push(sPID23,stack);
        rPatient_Commu(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_15; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rPatient_Commu(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID23 = stack.get(2);
    for(Element sCE2 : namedChildElements(sPID23,"CE.1"))
    {
        Patient.Communication t_communicatio = new Patient.Communication(); 
        t_resource9.addCommunication(t_communicatio);
        CodeableConceptDt t_language = new CodeableConceptDt(); 
        t_communicatio.setLanguage(t_language);
        CodingDt t_coding = new CodingDt(); 
        t_language.addCoding(t_coding);
        t_language.setText(getText(sCE2));
        t_coding.setDisplay(getText(sCE2));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rFiller42(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK16 : namedChildElements(sourceTop,"NK1"))
    {

        List<Element> stack1 = push(sNK16,stack);
        rAddress2(stack1, t_contact);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)NK1; 
* @param t_contact - reached by target path: Bundle.entry.resource.contact
*/
protected void rAddress2(List<Element> stack, Patient.Contact t_contact) throws Exception
{
    Element sNK16 = stack.get(1);
    for(Element sNK17 : namedChildElements(sNK16,"NK1.4"))
    {
        AddressDt t_address4 = new AddressDt(); 
        t_contact.setAddress(t_address4);

        List<Element> stack1 = push(sNK17,stack);

        Node sPostalCode1 = namedChildNode(sNK17,"XAD.5");
        if (sPostalCode1 != null) t_address4.setPostalCode(getText(sPostalCode1));

        Node sXAD5 = namedChildNode(sNK17,"XAD.2");
        if (sXAD5 != null) t_address4.getLine().add(new StringDt(getText(sXAD5)));

        Node sXAD6 = namedChildNode(sNK17,"XAD.1");
        if (sXAD6 != null) t_address4.getLine().add(new StringDt(getText(sXAD6)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource10 - reached by target path: Bundle.entry.resource
*/
protected void rCodeableConce2(List<Element> stack, Encounter t_resource10) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV110 : namedChildElements(sourceTop,"PV1"))
    {
        CodeableConceptDt t_type = new CodeableConceptDt(); 
        t_resource10.addType(t_type);

        List<Element> stack1 = push(sPV110,stack);

        Node sText = namedChildNode(sPV110,"PV1.18");
        if (sText != null) t_type.setText(getText(sText));
        rCoding1(stack1, t_type);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; 
* @param t_type - reached by target path: Bundle.entry.resource.type
*/
protected void rCoding1(List<Element> stack, CodeableConceptDt t_type) throws Exception
{
    Element sPV110 = stack.get(1);
    for(Element sPV111 : namedChildElements(sPV110,"PV1.2"))
    {
        CodingDt t_coding1 = new CodingDt(); 
        t_type.addCoding(t_coding1);
        t_coding1.setDisplay(getText(sPV111));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rFiller43(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID24 : namedChildElements(sourceTop,"PID"))
    {

        List<Element> stack1 = push(sPID24,stack);
        rHumanName2(stack1, t_resource9);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rHumanName2(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sPID24 = stack.get(1);
    for(Element sPID25 : namedChildElements(sPID24,"PID.9"))
    if (valueTest(sPID25,"XPN.1", "Miah","="))
    {
        HumanNameDt t_name3 = new HumanNameDt(); 
        t_resource9.addName(t_name3);

        List<Element> stack1 = push(sPID25,stack);

        Node sXPN5 = namedChildNode(sPID25,"XPN.5");
        if (sXPN5 != null) t_name3.getPrefix().add(new StringDt(getText(sXPN5)));

        Node sXPN6 = namedChildNode(sPID25,"XPN.2");
        if (sXPN6 != null) t_name3.getGiven().add(new StringDt(getText(sXPN6)));

        Node sXPN7 = namedChildNode(sPID25,"XPN.1");
        if (sXPN7 != null) t_name3.getFamily().add(new StringDt(getText(sXPN7)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource9 - reached by target path: Bundle.entry.resource
*/
protected void rHumanName3(List<Element> stack, Patient t_resource9) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID26 : namedChildElements(sourceTop,"PID"))
    {
        HumanNameDt t_name4 = new HumanNameDt(); 
        t_resource9.addName(t_name4);

        List<Element> stack1 = push(sPID26,stack);
        rFiller44(stack1, t_name4);
        rFiller45(stack1, t_name4);
        rFiller46(stack1, t_name4);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_name4 - reached by target path: Bundle.entry.resource.name
*/
protected void rFiller44(List<Element> stack, HumanNameDt t_name4) throws Exception
{
    Element sPID26 = stack.get(1);
    for(Element sPID27 : namedChildElements(sPID26,"PID.5"))
    {

        List<Element> stack1 = push(sPID27,stack);

        Node sXPN8 = namedChildNode(sPID27,"XPN.5");
        if (sXPN8 != null) t_name4.getPrefix().add(new StringDt(getText(sXPN8)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_name4 - reached by target path: Bundle.entry.resource.name
*/
protected void rFiller45(List<Element> stack, HumanNameDt t_name4) throws Exception
{
    Element sPID26 = stack.get(1);
    for(Element sPID28 : namedChildElements(sPID26,"PID.5"))
    {

        List<Element> stack1 = push(sPID28,stack);

        Node sXPN9 = namedChildNode(sPID28,"XPN.2");
        if (sXPN9 != null) t_name4.getGiven().add(new StringDt(getText(sXPN9)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_name4 - reached by target path: Bundle.entry.resource.name
*/
protected void rFiller46(List<Element> stack, HumanNameDt t_name4) throws Exception
{
    Element sPID26 = stack.get(1);
    for(Element sPID29 : namedChildElements(sPID26,"PID.9"))
    {

        List<Element> stack1 = push(sPID29,stack);

        Node sXPN10 = namedChildNode(sPID29,"XPN.1");
        if (sXPN10 != null) t_name4.getFamily().add(new StringDt(getText(sXPN10)));
    }
}
}
