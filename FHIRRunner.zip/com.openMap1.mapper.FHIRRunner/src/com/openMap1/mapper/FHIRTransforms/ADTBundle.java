package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import ca.uhn.fhir.model.primitive.*;
import ca.uhn.fhir.model.dstu2.resource.BaseResource;

import ca.uhn.fhir.model.dstu2.resource.Patient.Contact;
import ca.uhn.fhir.model.dstu2.resource.Practitioner;
import ca.uhn.fhir.model.dstu2.resource.Location;
import ca.uhn.fhir.model.dstu2.composite.ContactPointDt;
import ca.uhn.fhir.model.dstu2.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu2.resource.Patient.Communication;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.resource.Patient;
import ca.uhn.fhir.model.dstu2.composite.HumanNameDt;
import ca.uhn.fhir.model.dstu2.resource.MessageHeader;
import ca.uhn.fhir.model.dstu2.resource.Encounter;
import ca.uhn.fhir.model.dstu2.valueset.AddressUseEnum;
import ca.uhn.fhir.model.dstu2.resource.Encounter.Hospitalization;
import ca.uhn.fhir.model.dstu2.resource.Organization;
import ca.uhn.fhir.model.dstu2.resource.MessageHeader.Source;
import ca.uhn.fhir.model.dstu2.composite.CodingDt;
import ca.uhn.fhir.model.dstu2.composite.IdentifierDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle;
import ca.uhn.fhir.model.dstu2.composite.AddressDt;

public class ADTBundle extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Mon Nov 13 16:03:19 GMT 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public BaseResource transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   return topRule(root);
}

//--------------------------------------------------------------------------------------
//                                  Bundle and Patient and Encounter                                  
//--------------------------------------------------------------------------------------

/**
* @param sourceTop
*/
protected BaseResource topRule(Element sourceTop) throws Exception
{
    if (!("ADT_A05".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'ADT_A05'");
    Bundle target = new Bundle();
    Bundle.Entry t_entry_Patient_Bund = new Bundle.Entry(); 
    target.addEntry(t_entry_Patient_Bund);
    Bundle.Entry t_entry_Encounter_Bu = new Bundle.Entry(); 
    target.addEntry(t_entry_Encounter_Bu);
    Patient t_resource_Patient = new Patient();
    t_entry_Patient_Bund.setResource(t_resource_Patient);
    Encounter t_resource_Encounter = new Encounter();
    t_entry_Encounter_Bu.setResource(t_resource_Encounter);
    Patient.Contact t_contact_Patient_Co = new Patient.Contact(); 
    t_resource_Patient.addContact(t_contact_Patient_Co);
    HumanNameDt t_name_HumanName5 = new HumanNameDt(); 
    t_contact_Patient_Co.setName(t_name_HumanName5);

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rName_HumanName(stack1, t_resource_Patient);
    rIdentifier_Identifi(stack1, t_resource_Patient);
    rBundle_Entry_Messag(stack1, target);
    rAddress_Address(stack1, t_resource_Patient);
    rBundle_Entry_Organi(stack1, target);
    rBundle_Entry_Locati(stack1, target);
    rGiven_string1(stack1, t_name_HumanName5);
    rBundle_Entry_Locati1(stack1, target);
    rBundle_Entry_Locati2(stack1, target);
    rBundle_Entry_Locati3(stack1, target);
    rBundle_Entry_Practi(stack1, target);
    rRelationship_Codeab(stack1, t_contact_Patient_Co);
    rIdentifier_Identifi1(stack1, t_resource_Patient);
    rBundle_Entry_Practi1(stack1, target);
    rIdentifier_Identifi3(stack1, t_resource_Patient);
    rEncounter_Hospitali(stack1, t_resource_Encounter);
    rAddress_Address1(stack1, t_resource_Patient);
    rBundle_Entry_Locati4(stack1, target);
    rTelecom_ContactPoin(stack1, t_contact_Patient_Co);
    rTelecom_ContactPoin1(stack1, t_resource_Patient);
    rReason_CodeableConc(stack1, t_resource_Encounter);
    rName_HumanName1(stack1, t_resource_Patient);
    rFamily_string1(stack1, t_name_HumanName5);
    rPatient_Communicati(stack1, t_resource_Patient);
    rAddress_Address2(stack1, t_contact_Patient_Co);
    rType_CodeableConcep(stack1, t_resource_Encounter);
    rName_HumanName2(stack1, t_resource_Patient);
    rName_HumanName3(stack1, t_resource_Patient);
    return target;
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_name_HumanName5 - reached by target path: Bundle.entry.resource.contact.name
*/
protected void rGiven_string1(List<Element> stack, HumanNameDt t_name_HumanName5) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK1 : namedChildElements(sourceTop,"NK1"))
    {
        List<Element> stack1 = push(sNK1,stack);
         for(Element sNK11 : namedChildElements(sNK1,"NK1.2"))
         {
             List<Element> stack2 = push(sNK11,stack1);

             Node sXPN2 = namedChildNode(sNK11,"XPN.2");
             if (sXPN2 != null) t_name_HumanName5.getGiven().add(new StringDt(getText(sXPN2)));
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_contact_Patient_Co - reached by target path: Bundle.entry.resource.contact
*/
protected void rRelationship_Codeab(List<Element> stack, Patient.Contact t_contact_Patient_Co) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK12 : namedChildElements(sourceTop,"NK1"))
    {
        List<Element> stack1 = push(sNK12,stack);
         for(Element sNK13 : namedChildElements(sNK12,"NK1.7"))
         {
             List<Element> stack2 = push(sNK13,stack1);
              for(Element sCE : namedChildElements(sNK13,"CE.1"))
              {
                  CodeableConceptDt t_relationship_Codea = new CodeableConceptDt(); 
                  t_contact_Patient_Co.addRelationship(t_relationship_Codea);
                  t_relationship_Codea.setText(getText(sCE));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_contact_Patient_Co - reached by target path: Bundle.entry.resource.contact
*/
protected void rTelecom_ContactPoin(List<Element> stack, Patient.Contact t_contact_Patient_Co) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK14 : namedChildElements(sourceTop,"NK1"))
    {
        List<Element> stack1 = push(sNK14,stack);
         for(Element sNK15 : namedChildElements(sNK14,"NK1.5"))
         {
             List<Element> stack2 = push(sNK15,stack1);
              for(Element sXTN : namedChildElements(sNK15,"XTN.1"))
              {
                  ContactPointDt t_telecom_ContactPoi1 = new ContactPointDt(); 
                  t_contact_Patient_Co.addTelecom(t_telecom_ContactPoi1);
                  t_telecom_ContactPoi1.setValue(getText(sXTN));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_contact_Patient_Co - reached by target path: Bundle.entry.resource.contact
*/
protected void rAddress_Address2(List<Element> stack, Patient.Contact t_contact_Patient_Co) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sNK16 : namedChildElements(sourceTop,"NK1"))
    {
        List<Element> stack1 = push(sNK16,stack);
         for(Element sNK17 : namedChildElements(sNK16,"NK1.4"))
         {
             AddressDt t_address_Address4 = new AddressDt(); 
             t_contact_Patient_Co.setAddress(t_address_Address4);
             List<Element> stack2 = push(sNK17,stack1);

             Node sPostalCode1 = namedChildNode(sNK17,"XAD.5");
             if (sPostalCode1 != null) t_address_Address4.setPostalCode(getText(sPostalCode1));

             Node sXAD5 = namedChildNode(sNK17,"XAD.2");
             if (sXAD5 != null) t_address_Address4.getLine().add(new StringDt(getText(sXAD5)));

             Node sXAD6 = namedChildNode(sNK17,"XAD.1");
             if (sXAD6 != null) t_address_Address4.getLine().add(new StringDt(getText(sXAD6)));
         }
    }
}

//--------------------------------------------------------------------------------------
//                                  Encounter                                  
//--------------------------------------------------------------------------------------

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Encounter - reached by target path: Bundle.entry.resource
*/
protected void rEncounter_Hospitali(List<Element> stack, Encounter t_resource_Encounter) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV16 : namedChildElements(sourceTop,"PV1"))
    {
        List<Element> stack1 = push(sPV16,stack);
         for(Element sPV17 : namedChildElements(sPV16,"PV1.36"))
         {
             Encounter.Hospitalization t_hospitalization_En = new Encounter.Hospitalization(); 
             t_resource_Encounter.setHospitalization(t_hospitalization_En);
             CodeableConceptDt t_dischargeDispositi = new CodeableConceptDt(); 
             t_hospitalization_En.setDischargeDisposition(t_dischargeDispositi);
             t_dischargeDispositi.setText(getText(sPV17));
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Encounter - reached by target path: Bundle.entry.resource
*/
protected void rReason_CodeableConc(List<Element> stack, Encounter t_resource_Encounter) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV2 : namedChildElements(sourceTop,"PV2"))
    {
        List<Element> stack1 = push(sPV2,stack);
         for(Element sPV21 : namedChildElements(sPV2,"PV2.4"))
         {
             List<Element> stack2 = push(sPV21,stack1);
              for(Element sCE1 : namedChildElements(sPV21,"CE.1"))
              {
                  CodeableConceptDt t_reason_CodeableCon = new CodeableConceptDt(); 
                  t_resource_Encounter.addReason(t_reason_CodeableCon);
                  t_reason_CodeableCon.setText(getText(sCE1));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Encounter - reached by target path: Bundle.entry.resource
*/
protected void rType_CodeableConcep(List<Element> stack, Encounter t_resource_Encounter) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV110 : namedChildElements(sourceTop,"PV1"))
    {
        CodeableConceptDt t_type_CodeableConce = new CodeableConceptDt(); 
        t_resource_Encounter.addType(t_type_CodeableConce);
        List<Element> stack1 = push(sPV110,stack);

        Node sText = namedChildNode(sPV110,"PV1.18");
        if (sText != null) t_type_CodeableConce.setText(getText(sText));
        rCoding_Coding(stack1, t_type_CodeableConce);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PV1; 
* @param t_type_CodeableConce - reached by target path: Bundle.entry.resource.type
*/
protected void rCoding_Coding(List<Element> stack, CodeableConceptDt t_type_CodeableConce) throws Exception
{
    Element sPV110 = stack.get(1);
    for(Element sPV111 : namedChildElements(sPV110,"PV1.2"))
    {
        CodingDt t_coding_Coding1 = new CodingDt(); 
        t_type_CodeableConce.addCoding(t_coding_Coding1);
        t_coding_Coding1.setDisplay(getText(sPV111));
    }
}

//--------------------------------------------------------------------------------------
//                                  Practitioner                                  
//--------------------------------------------------------------------------------------

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Practi(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPD1 : namedChildElements(sourceTop,"PD1"))
    {
        List<Element> stack1 = push(sPD1,stack);
         for(Element sPD11 : namedChildElements(sPD1,"PD1.4"))
         {
             List<Element> stack2 = push(sPD11,stack1);
              for(Element sXCN : namedChildElements(sPD11,"XCN.1"))
              {
                  Bundle.Entry t_entry_Practitioner = new Bundle.Entry(); 
                  target.addEntry(t_entry_Practitioner);
                  Practitioner t_resource_Practitio = new Practitioner();
                  t_entry_Practitioner.setResource(t_resource_Practitio);
                  IdentifierDt t_identifier_Identif = new IdentifierDt(); 
                  t_resource_Practitio.addIdentifier(t_identifier_Identif);
                  t_identifier_Identif.setValue(getText(sXCN));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Practi1(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sEVN : namedChildElements(sourceTop,"EVN"))
    {
        List<Element> stack1 = push(sEVN,stack);
         for(Element sEVN1 : namedChildElements(sEVN,"EVN.5"))
         {
             Bundle.Entry t_entry_Practitioner1 = new Bundle.Entry(); 
             target.addEntry(t_entry_Practitioner1);
             Practitioner t_resource_Practitio1 = new Practitioner();
             t_entry_Practitioner1.setResource(t_resource_Practitio1);
             HumanNameDt t_name_HumanName = new HumanNameDt(); 
             t_resource_Practitio1.setName(t_name_HumanName);
             List<Element> stack2 = push(sEVN1,stack1);

             Node sXCN1 = namedChildNode(sEVN1,"XCN.3");
             if (sXCN1 != null) t_name_HumanName.getGiven().add(new StringDt(getText(sXCN1)));

             Node sXCN2 = namedChildNode(sEVN1,"XCN.2");
             if (sXCN2 != null) t_name_HumanName.getFamily().add(new StringDt(getText(sXCN2)));
             rIdentifier_Identifi2(stack1, t_resource_Practitio1);
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)EVN; (2)EVN_5; 
* @param t_resource_Practitio1 - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier_Identifi2(List<Element> stack, Practitioner t_resource_Practitio1) throws Exception
{
    Element sEVN1 = stack.get(2);
    for(Element sXCN3 : namedChildElements(sEVN1,"XCN.1"))
    {
        IdentifierDt t_identifier_Identif1 = new IdentifierDt(); 
        t_resource_Practitio1.addIdentifier(t_identifier_Identif1);
        t_identifier_Identif1.setValue(getText(sXCN3));
    }
}

//--------------------------------------------------------------------------------------
//                                  Location                                  
//--------------------------------------------------------------------------------------

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Locati1(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV1 : namedChildElements(sourceTop,"PV1"))
    {
        List<Element> stack1 = push(sPV1,stack);
         for(Element sPV11 : namedChildElements(sPV1,"PV1.3"))
         {
             List<Element> stack2 = push(sPV11,stack1);
              for(Element sPL : namedChildElements(sPV11,"PL.3"))
              {
                  Bundle.Entry t_entry_Location_Bun1 = new Bundle.Entry(); 
                  target.addEntry(t_entry_Location_Bun1);
                  Location t_resource_Location1 = new Location();
                  t_entry_Location_Bun1.setResource(t_resource_Location1);
                  t_resource_Location1.setName(getText(sPL));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Locati2(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV12 : namedChildElements(sourceTop,"PV1"))
    {
        List<Element> stack1 = push(sPV12,stack);
         for(Element sPV13 : namedChildElements(sPV12,"PV1.3"))
         {
             List<Element> stack2 = push(sPV13,stack1);
              for(Element sPL1 : namedChildElements(sPV13,"PL.2"))
              {
                  Bundle.Entry t_entry_Location_Bun2 = new Bundle.Entry(); 
                  target.addEntry(t_entry_Location_Bun2);
                  Location t_resource_Location2 = new Location();
                  t_entry_Location_Bun2.setResource(t_resource_Location2);
                  t_resource_Location2.setName(getText(sPL1));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Locati3(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV14 : namedChildElements(sourceTop,"PV1"))
    {
        List<Element> stack1 = push(sPV14,stack);
         for(Element sPV15 : namedChildElements(sPV14,"PV1.3"))
         {
             List<Element> stack2 = push(sPV15,stack1);
              for(Element sPL2 : namedChildElements(sPV15,"PL.1"))
              {
                  Bundle.Entry t_entry_Location_Bun3 = new Bundle.Entry(); 
                  target.addEntry(t_entry_Location_Bun3);
                  Location t_resource_Location3 = new Location();
                  t_entry_Location_Bun3.setResource(t_resource_Location3);
                  t_resource_Location3.setName(getText(sPL2));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Locati4(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPV18 : namedChildElements(sourceTop,"PV1"))
    {
        List<Element> stack1 = push(sPV18,stack);
         for(Element sPV19 : namedChildElements(sPV18,"PV1.6"))
         {
             List<Element> stack2 = push(sPV19,stack1);
              for(Element sPL3 : namedChildElements(sPV19,"PL.1"))
              {
                  Bundle.Entry t_entry_Location_Bun4 = new Bundle.Entry(); 
                  target.addEntry(t_entry_Location_Bun4);
                  Location t_resource_Location4 = new Location();
                  t_entry_Location_Bun4.setResource(t_resource_Location4);
                  t_resource_Location4.setName(getText(sPL3));
              }
         }
    }
}

//--------------------------------------------------------------------------------------
//                                  Patient                                  
//--------------------------------------------------------------------------------------

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rName_HumanName(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID,stack);
         for(Element sPID1 : namedChildElements(sPID,"PID.5"))
         if (valueTest(sPID1,"XPN.1", "MIAH","="))
         {
             HumanNameDt t_name_HumanName1 = new HumanNameDt(); 
             t_resource_Patient.addName(t_name_HumanName1);
             List<Element> stack2 = push(sPID1,stack1);

             Node sXPN = namedChildNode(sPID1,"XPN.5");
             if (sXPN != null) t_name_HumanName1.getPrefix().add(new StringDt(getText(sXPN)));

             Node sXPN1 = namedChildNode(sPID1,"XPN.2");
             if (sXPN1 != null) t_name_HumanName1.getGiven().add(new StringDt(getText(sXPN1)));
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier_Identifi(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID2 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID2,stack);
         for(Element sPID3 : namedChildElements(sPID2,"PID.2"))
         {
             List<Element> stack2 = push(sPID3,stack1);
              for(Element sCX : namedChildElements(sPID3,"CX.1"))
              {
                  IdentifierDt t_identifier_Identif2 = new IdentifierDt(); 
                  t_resource_Patient.addIdentifier(t_identifier_Identif2);
                  t_identifier_Identif2.setValue(getText(sCX));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier_Identifi1(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID10 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID10,stack);
         for(Element sPID11 : namedChildElements(sPID10,"PID.3"))
         {
             List<Element> stack2 = push(sPID11,stack1);
              for(Element sCX1 : namedChildElements(sPID11,"CX.1"))
              {
                  IdentifierDt t_identifier_Identif3 = new IdentifierDt(); 
                  t_resource_Patient.addIdentifier(t_identifier_Identif3);
                  t_identifier_Identif3.setValue(getText(sCX1));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rIdentifier_Identifi3(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID12 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID12,stack);
         for(Element sPID13 : namedChildElements(sPID12,"PID.19"))
         {
             IdentifierDt t_identifier_Identif4 = new IdentifierDt(); 
             t_resource_Patient.addIdentifier(t_identifier_Identif4);
             t_identifier_Identif4.setValue(getText(sPID13));
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rAddress_Address1(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID14 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID14,stack);
         for(Element sPID15 : namedChildElements(sPID14,"PID.11"))
         if (valueTest(sPID15,"XAD.1", "Flat 1","="))
         {
             AddressDt t_address_Address3 = new AddressDt(); 
             t_resource_Patient.addAddress(t_address_Address3);
             List<Element> stack2 = push(sPID15,stack1);

             Node sDistrict = namedChildNode(sPID15,"XAD.4");
             if (sDistrict != null) t_address_Address3.setDistrict(getText(sDistrict));

             Node sPostalCode = namedChildNode(sPID15,"XAD.5");
             if (sPostalCode != null) t_address_Address3.setPostalCode(getText(sPostalCode));

             Node sUse = namedChildNode(sPID15,"XAD.7");
             if (sUse != null) t_address_Address3.setUse(AddressUseEnum.forCode(getText(sUse)));

             Node sXAD3 = namedChildNode(sPID15,"XAD.2");
             if (sXAD3 != null) t_address_Address3.getLine().add(new StringDt(getText(sXAD3)));

             Node sXAD4 = namedChildNode(sPID15,"XAD.1");
             if (sXAD4 != null) t_address_Address3.getLine().add(new StringDt(getText(sXAD4)));
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rTelecom_ContactPoin1(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID16 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID16,stack);
         for(Element sPID17 : namedChildElements(sPID16,"PID.13"))
         {
             List<Element> stack2 = push(sPID17,stack1);
              for(Element sXTN1 : namedChildElements(sPID17,"XTN.1"))
              {
                  ContactPointDt t_telecom_ContactPoi = new ContactPointDt(); 
                  t_resource_Patient.addTelecom(t_telecom_ContactPoi);
                  t_telecom_ContactPoi.setValue(getText(sXTN1));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rName_HumanName1(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID18 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID18,stack);
         for(Element sPID19 : namedChildElements(sPID18,"PID.9"))
         {
             List<Element> stack2 = push(sPID19,stack1);
              for(Element sXPN3 : namedChildElements(sPID19,"XPN.1"))
              if (valueTest(sXPN3,"ancestor::PID.9/XPN.2", "Janet","="))
              {
                  HumanNameDt t_name_HumanName2 = new HumanNameDt(); 
                  t_resource_Patient.addName(t_name_HumanName2);
                  t_name_HumanName2.getGiven().add(new StringDt(getText(sXPN3)));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_name_HumanName5 - reached by target path: Bundle.entry.resource.contact.name
*/
protected void rFamily_string1(List<Element> stack, HumanNameDt t_name_HumanName5) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID20 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID20,stack);
         for(Element sPID21 : namedChildElements(sPID20,"PID.9"))
         {
             List<Element> stack2 = push(sPID21,stack1);

             Node sXPN4 = namedChildNode(sPID21,"XPN.1");
             if (sXPN4 != null) t_name_HumanName5.getFamily().add(new StringDt(getText(sXPN4)));
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rPatient_Communicati(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID22 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID22,stack);
         for(Element sPID23 : namedChildElements(sPID22,"PID.15"))
         {
             List<Element> stack2 = push(sPID23,stack1);
              for(Element sCE2 : namedChildElements(sPID23,"CE.1"))
              {
                  Patient.Communication t_communication_Pati = new Patient.Communication(); 
                  t_resource_Patient.addCommunication(t_communication_Pati);
                  CodeableConceptDt t_language_CodeableC = new CodeableConceptDt(); 
                  t_communication_Pati.setLanguage(t_language_CodeableC);
                  CodingDt t_coding_Coding = new CodingDt(); 
                  t_language_CodeableC.addCoding(t_coding_Coding);
                  t_language_CodeableC.setText(getText(sCE2));
                  t_coding_Coding.setDisplay(getText(sCE2));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rName_HumanName2(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID24 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID24,stack);
         for(Element sPID25 : namedChildElements(sPID24,"PID.9"))
         if (valueTest(sPID25,"XPN.1", "Miah","="))
         {
             HumanNameDt t_name_HumanName3 = new HumanNameDt(); 
             t_resource_Patient.addName(t_name_HumanName3);
             List<Element> stack2 = push(sPID25,stack1);

             Node sXPN5 = namedChildNode(sPID25,"XPN.5");
             if (sXPN5 != null) t_name_HumanName3.getPrefix().add(new StringDt(getText(sXPN5)));

             Node sXPN6 = namedChildNode(sPID25,"XPN.2");
             if (sXPN6 != null) t_name_HumanName3.getGiven().add(new StringDt(getText(sXPN6)));

             Node sXPN7 = namedChildNode(sPID25,"XPN.1");
             if (sXPN7 != null) t_name_HumanName3.getFamily().add(new StringDt(getText(sXPN7)));
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rName_HumanName3(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID26 : namedChildElements(sourceTop,"PID"))
    {
        HumanNameDt t_name_HumanName4 = new HumanNameDt(); 
        t_resource_Patient.addName(t_name_HumanName4);
        List<Element> stack1 = push(sPID26,stack);
        rPrefix_string2(stack1, t_name_HumanName4);
        rGiven_string4(stack1, t_name_HumanName4);
        rFamily_string3(stack1, t_name_HumanName4);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_name_HumanName4 - reached by target path: Bundle.entry.resource.name
*/
protected void rPrefix_string2(List<Element> stack, HumanNameDt t_name_HumanName4) throws Exception
{
    Element sPID26 = stack.get(1);
    for(Element sPID27 : namedChildElements(sPID26,"PID.5"))
    {
        List<Element> stack1 = push(sPID27,stack);

        Node sXPN8 = namedChildNode(sPID27,"XPN.5");
        if (sXPN8 != null) t_name_HumanName4.getPrefix().add(new StringDt(getText(sXPN8)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_name_HumanName4 - reached by target path: Bundle.entry.resource.name
*/
protected void rGiven_string4(List<Element> stack, HumanNameDt t_name_HumanName4) throws Exception
{
    Element sPID26 = stack.get(1);
    for(Element sPID28 : namedChildElements(sPID26,"PID.5"))
    {
        List<Element> stack1 = push(sPID28,stack);

        Node sXPN9 = namedChildNode(sPID28,"XPN.2");
        if (sXPN9 != null) t_name_HumanName4.getGiven().add(new StringDt(getText(sXPN9)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_name_HumanName4 - reached by target path: Bundle.entry.resource.name
*/
protected void rFamily_string3(List<Element> stack, HumanNameDt t_name_HumanName4) throws Exception
{
    Element sPID26 = stack.get(1);
    for(Element sPID29 : namedChildElements(sPID26,"PID.9"))
    {
        List<Element> stack1 = push(sPID29,stack);

        Node sXPN10 = namedChildNode(sPID29,"XPN.1");
        if (sXPN10 != null) t_name_HumanName4.getFamily().add(new StringDt(getText(sXPN10)));
    }
}

//--------------------------------------------------------------------------------------
//                                  MessageHeader                                  
//--------------------------------------------------------------------------------------

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Messag(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sMSH : namedChildElements(sourceTop,"MSH"))
    {
        Bundle.Entry t_entry_MessageHeade = new Bundle.Entry(); 
        target.addEntry(t_entry_MessageHeade);
        MessageHeader t_resource_MessageHe = new MessageHeader();
        t_entry_MessageHeade.setResource(t_resource_MessageHe);
        MessageHeader.Source t_source_MessageHead = new MessageHeader.Source(); 
        t_resource_MessageHe.setSource(t_source_MessageHead);
        List<Element> stack1 = push(sMSH,stack);
        pSoftware(stack1, t_source_MessageHead);
        pName(stack1, t_source_MessageHead);
        rEvent_Coding(stack1, t_resource_MessageHe);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)MSH; 
* @param t_source_MessageHead - reached by target path: Bundle.entry.resource.source
*/
protected void pSoftware(List<Element> stack, MessageHeader.Source t_source_MessageHead) throws Exception
{
    Element sMSH = stack.get(1);
    for(Element sMSH1 : namedChildElements(sMSH,"MSH.3"))
    {
        List<Element> stack1 = push(sMSH1,stack);

        Node sSoftware = namedChildNode(sMSH1,"HD.1");
        if (sSoftware != null) t_source_MessageHead.setSoftware(getText(sSoftware));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)MSH; 
* @param t_source_MessageHead - reached by target path: Bundle.entry.resource.source
*/
protected void pName(List<Element> stack, MessageHeader.Source t_source_MessageHead) throws Exception
{
    Element sMSH = stack.get(1);
    for(Element sMSH2 : namedChildElements(sMSH,"MSH.6"))
    {
        List<Element> stack1 = push(sMSH2,stack);

        Node sName = namedChildNode(sMSH2,"HD.1");
        if (sName != null) t_source_MessageHead.setName(getText(sName));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)MSH; 
* @param t_resource_MessageHe - reached by target path: Bundle.entry.resource
*/
protected void rEvent_Coding(List<Element> stack, MessageHeader t_resource_MessageHe) throws Exception
{
    Element sMSH = stack.get(1);
    for(Element sMSH3 : namedChildElements(sMSH,"MSH.12"))
    {
        List<Element> stack1 = push(sMSH3,stack);
         for(Element sVID : namedChildElements(sMSH3,"VID.1"))
         {
             CodingDt t_event_Coding = new CodingDt(); 
             t_resource_MessageHe.setEvent(t_event_Coding);
             t_event_Coding.setVersion(getText(sVID));
         }
    }
}

//--------------------------------------------------------------------------------------
//                                  Organization and Location                                  
//--------------------------------------------------------------------------------------

/**
* @param stack - source elements (0)ADT_A05; 
* @param t_resource_Patient - reached by target path: Bundle.entry.resource
*/
protected void rAddress_Address(List<Element> stack, Patient t_resource_Patient) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID4 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID4,stack);
         for(Element sPID5 : namedChildElements(sPID4,"PID.11"))
         {
             List<Element> stack2 = push(sPID5,stack1);
              for(Element sXAD : namedChildElements(sPID5,"XAD.4"))
              if (valueTest(sXAD,"ancestor::PID.11/XAD.1", "Flat 1","="))
              {
                  AddressDt t_address_Address2 = new AddressDt(); 
                  t_resource_Patient.addAddress(t_address_Address2);
                  t_address_Address2.setDistrict(getText(sXAD));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Organi(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID6 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID6,stack);
         for(Element sPID7 : namedChildElements(sPID6,"PID.11"))
         {
             List<Element> stack2 = push(sPID7,stack1);
              for(Element sXAD1 : namedChildElements(sPID7,"XAD.4"))
              if (valueTest(sXAD1,"ancestor::PID.11/XAD.1", "Flat 1","="))
              {
                  Bundle.Entry t_entry_Organization = new Bundle.Entry(); 
                  target.addEntry(t_entry_Organization);
                  Organization t_resource_Organizat = new Organization();
                  t_entry_Organization.setResource(t_resource_Organizat);
                  AddressDt t_address_Address = new AddressDt(); 
                  t_resource_Organizat.addAddress(t_address_Address);
                  t_address_Address.setCity(getText(sXAD1));
              }
         }
    }
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
protected void rBundle_Entry_Locati(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID8 : namedChildElements(sourceTop,"PID"))
    {
        List<Element> stack1 = push(sPID8,stack);
         for(Element sPID9 : namedChildElements(sPID8,"PID.11"))
         {
             List<Element> stack2 = push(sPID9,stack1);
              for(Element sXAD2 : namedChildElements(sPID9,"XAD.4"))
              if (valueTest(sXAD2,"ancestor::PID.11/XAD.1", "Flat 1","="))
              {
                  Bundle.Entry t_entry_Location_Bun = new Bundle.Entry(); 
                  target.addEntry(t_entry_Location_Bun);
                  Location t_resource_Location = new Location();
                  t_entry_Location_Bun.setResource(t_resource_Location);
                  AddressDt t_address_Address1 = new AddressDt(); 
                  t_resource_Location.setAddress(t_address_Address1);
                  t_address_Address1.setCity(getText(sXAD2));
              }
         }
    }
}
}
