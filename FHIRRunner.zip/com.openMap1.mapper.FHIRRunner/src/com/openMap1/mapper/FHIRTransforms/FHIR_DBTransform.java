package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import ca.uhn.fhir.model.primitive.*;
import ca.uhn.fhir.model.dstu2.resource.BaseResource;

import ca.uhn.fhir.model.dstu2.composite.IdentifierDt;
import ca.uhn.fhir.model.dstu2.resource.Patient;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.valueset.AdministrativeGenderEnum;
import ca.uhn.fhir.model.dstu2.composite.HumanNameDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle;

public class FHIR_DBTransform extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Wed Oct 11 12:36:39 BST 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public BaseResource transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   return topRule(root);
}

/**
* @param sourceTop
*/
private BaseResource topRule(Element sourceTop) throws Exception
{
    if (!("database".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'database'");
    Bundle target = new Bundle();

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rFiller(stack1, target);
    return target;
}

/**
* @param stack - source elements (0)database; 
* @param target - reached by target path: Bundle
*/
private void rFiller(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPATIENT : namedChildElements(sourceTop,"PATIENT"))
    {

        List<Element> stack1 = push(sPATIENT,stack);
        rBundle_Entry_(stack1, target);
    }
}

/**
* @param stack - source elements (0)database; (1)PATIENT; 
* @param target - reached by target path: Bundle
*/
private void rBundle_Entry_(List<Element> stack, Bundle target) throws Exception
{
    Element sPATIENT = stack.get(1);
    for(Element sRecord : namedChildElements(sPATIENT,"record"))
    {
        Bundle.Entry t_entry_Patien = new Bundle.Entry(); 
        target.addEntry(t_entry_Patien);
        Patient t_resource = new Patient();
        t_entry_Patien.setResource(t_resource);
        IdentifierDt t_identifier_o = new IdentifierDt(); 
        t_resource.addIdentifier(t_identifier_o);
        HumanNameDt t_name_usual = new HumanNameDt(); 
        t_resource.addName(t_name_usual);

        List<Element> stack1 = push(sRecord,stack);

        Node sValue = namedChildNode(sRecord,"FIRSTNAME");
        if (sValue != null) t_name_usual.getGiven().add(new StringDt(getText(sValue)));

        Node sFamily = namedChildNode(sRecord,"FAMILYNAME");
        if (sFamily != null) t_name_usual.getFamily().add(new StringDt(getText(sFamily)));

        Node sBirthDate = namedChildNode(sRecord,"DOB");
        if (sBirthDate != null) t_resource.setBirthDate(new DateDt(getText(sBirthDate)));

        Node sGender = namedChildNode(sRecord,"GENDER");
        if (sGender != null) t_resource.setGender(AdministrativeGenderEnum.forCode(getText(sGender)));
        pFiller(stack1, t_resource);
        rFiller1(stack1, t_resource);
    }
}

/**
* @param stack - source elements (0)database; (1)PATIENT; (2)record; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void pFiller(List<Element> stack, Patient t_resource) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPATIENT1 : namedChildElements(sourceTop,"PATIENT_IDS"))
    {

        List<Element> stack1 = push(sPATIENT1,stack);
        pFiller1(stack1, t_resource);
    }
}

/**
* @param stack - source elements (0)database; (1)PATIENT; (2)record; (3)PATIENT_IDS; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void pFiller1(List<Element> stack, Patient t_resource) throws Exception
{
    Element sPATIENT1 = stack.get(3);
    for(Element sRecord1 : namedChildElements(sPATIENT1,"record"))
    {

        List<Element> stack1 = push(sRecord1,stack);

        Node sId = namedChildNode(sRecord1,"INTERNAL_ID");
        if (sId != null) t_resource.setId(new IdDt(getText(sId)));
    }
}

/**
* @param stack - source elements (0)database; (1)PATIENT; (2)record; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void rFiller1(List<Element> stack, Patient t_resource) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPATIENT2 : namedChildElements(sourceTop,"PATIENT_IDS"))
    {

        List<Element> stack1 = push(sPATIENT2,stack);
        rIdentifier(stack1, t_resource);
    }
}

/**
* @param stack - source elements (0)database; (1)PATIENT; (2)record; (3)PATIENT_IDS; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void rIdentifier(List<Element> stack, Patient t_resource) throws Exception
{
    Element sPATIENT2 = stack.get(3);
    Element sRecord = stack.get(2);
    for(Element sRecord2 : namedChildElements(sPATIENT2,"record"))
    if ( crossTest(sRecord2, "INTERNAL_ID", sRecord, "INTERNAL_ID") && valueTest(sRecord2,"SOURCE", "NHS","="))
    {
        IdentifierDt t_identifier_n = new IdentifierDt(); 
        t_resource.addIdentifier(t_identifier_n);

        List<Element> stack1 = push(sRecord2,stack);

        Node sValue1 = namedChildNode(sRecord2,"EXTERNAL_ID");
        if (sValue1 != null) t_identifier_n.setValue(getText(sValue1));
    }
}
}
