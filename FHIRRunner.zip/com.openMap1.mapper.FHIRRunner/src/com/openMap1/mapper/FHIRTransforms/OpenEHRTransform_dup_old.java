package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import ca.uhn.fhir.model.primitive.*;
import ca.uhn.fhir.model.dstu2.resource.BaseResource;

import ca.uhn.fhir.model.dstu2.resource.Practitioner;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.composite.ResourceReferenceDt;
import ca.uhn.fhir.model.dstu2.composite.CodingDt;
import ca.uhn.fhir.model.dstu2.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu2.resource.AllergyIntolerance.Reaction;
import ca.uhn.fhir.model.dstu2.resource.AllergyIntolerance;
import ca.uhn.fhir.model.dstu2.composite.HumanNameDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle;

public class OpenEHRTransform_dup_old extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Thu Oct 12 15:08:47 BST 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public BaseResource transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   return topRule(root);
}

/**
* @param sourceTop
*/
private BaseResource topRule(Element sourceTop) throws Exception
{
    if (!("composition".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'composition'");
    if (valueTest(sourceTop,"archetype_details/archetype_id/value", "openEHR-EHR-COMPOSITION.adverse_reaction_list.v1","=") && valueTest(sourceTop,"@archetype_node_id", "openEHR-EHR-COMPOSITION.adverse_reaction_list.v1","=") && valueTest(sourceTop,"@xsi:type", "COMPOSITION","=") && valueTest(sourceTop,"name/value", "Adverse reaction list","="))
    {
        Bundle target = new Bundle();

        List<Element> stack1 = push(sourceTop, new Vector<Element>());
        pFiller(stack1, target);
        rFiller(stack1, target);
        rFiller5(stack1, target);
        return target;
    }
    else return null;
}

/**
* @param stack - source elements (0)composition; 
* @param target - reached by target path: Bundle
*/
private void pFiller(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sLanguage : namedChildElements(sourceTop,"language"))
    {

        List<Element> stack1 = push(sLanguage,stack);

        Node sLanguage1 = namedChildNode(sLanguage,"code_string");
        if (sLanguage1 != null) target.setLanguage(new CodeDt(getText(sLanguage1)));
    }
}

/**
* @param stack - source elements (0)composition; 
* @param target - reached by target path: Bundle
*/
private void rFiller(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sContent : namedChildElements(sourceTop,"content"))
    if (valueTest(sContent,"archetype_details/archetype_id/value", "openEHR-EHR-SECTION.allergies_adverse_reactions_rcp.v1","=") && valueTest(sContent,"@archetype_node_id", "openEHR-EHR-SECTION.allergies_adverse_reactions_rcp.v1","=") && valueTest(sContent,"@xsi:type", "SECTION","=") && valueTest(sContent,"name/value", "Allergies and adverse reactions","="))
    {

        List<Element> stack1 = push(sContent,stack);
        rBundle_Entry_(stack1, target);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; 
* @param target - reached by target path: Bundle
*/
private void rBundle_Entry_(List<Element> stack, Bundle target) throws Exception
{
    Element sContent = stack.get(1);
    for(Element sItems : namedChildElements(sContent,"items"))
    if (valueTest(sItems,"archetype_details/archetype_id/value", "openEHR-EHR-EVALUATION.adverse_reaction_risk.v1","=") && valueTest(sItems,"@archetype_node_id", "openEHR-EHR-EVALUATION.adverse_reaction_risk.v1","=") && valueTest(sItems,"@xsi:type", "EVALUATION","=") && valueTest(sItems,"name/value", "Adverse reaction risk","="))
    {
        Bundle.Entry t_entry_Allerg = new Bundle.Entry(); 
        target.addEntry(t_entry_Allerg);
        AllergyIntolerance t_resource = new AllergyIntolerance();
        t_entry_Allerg.setResource(t_resource);

        List<Element> stack1 = push(sItems,stack);
        rResourceRefer(stack1, t_resource);
        rAllergyIntole(stack1, t_resource);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void rResourceRefer(List<Element> stack, AllergyIntolerance t_resource) throws Exception
{
    Element sItems = stack.get(2);
    for(Element sSubject : namedChildElements(sItems,"subject"))
    {
        ResourceReferenceDt t_patient = new ResourceReferenceDt(); 
        t_resource.setPatient(t_patient);

        List<Element> stack1 = push(sSubject,stack);

        Node sDisplay = namedChildNode(sSubject,"name");
        if (sDisplay != null) t_patient.setDisplay(new StringDt(getText(sDisplay)));
        pFiller1(stack1, t_patient);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)subject; 
* @param t_patient - reached by target path: Bundle.entry.resource.patient
*/
private void pFiller1(List<Element> stack, ResourceReferenceDt t_patient) throws Exception
{
    Element sSubject = stack.get(3);
    for(Element sIdentifiers : namedChildElements(sSubject,"identifiers"))
    {

        List<Element> stack1 = push(sIdentifiers,stack);

        Node sReference = namedChildNode(sIdentifiers,"id");
        if (sReference != null) t_patient.setReference(new IdDt(getText(sReference)));
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void rAllergyIntole(List<Element> stack, AllergyIntolerance t_resource) throws Exception
{
    Element sItems = stack.get(2);
    for(Element sData : namedChildElements(sItems,"data"))
    if (valueTest(sData,"@archetype_node_id", "at0001","=") && valueTest(sData,"@xsi:type", "ITEM_TREE","=") && valueTest(sData,"name/value", "Tree","="))
    {
        AllergyIntolerance.Reaction t_reaction = new AllergyIntolerance.Reaction(); 
        t_resource.addReaction(t_reaction);

        List<Element> stack1 = push(sData,stack);
        rFiller1(stack1, t_reaction);
        rFiller4(stack1, t_reaction);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)data_at0001_Tree; 
* @param t_reaction - reached by target path: Bundle.entry.resource.reaction
*/
private void rFiller1(List<Element> stack, AllergyIntolerance.Reaction t_reaction) throws Exception
{
    Element sData = stack.get(3);
    for(Element sItems1 : namedChildElements(sData,"items"))
    if (valueTest(sItems1,"@archetype_node_id", "at0009","=") && valueTest(sItems1,"@xsi:type", "CLUSTER","=") && valueTest(sItems1,"name/value", "Reaction details","="))
    {

        List<Element> stack1 = push(sItems1,stack);
        rFiller2(stack1, t_reaction);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)data_at0001_Tree; (4)items_at0009_Reaction_event; 
* @param t_reaction - reached by target path: Bundle.entry.resource.reaction
*/
private void rFiller2(List<Element> stack, AllergyIntolerance.Reaction t_reaction) throws Exception
{
    Element sItems1 = stack.get(4);
    for(Element sItems2 : namedChildElements(sItems1,"items"))
    if (valueTest(sItems2,"@archetype_node_id", "at0011","=") && valueTest(sItems2,"@xsi:type", "ELEMENT","=") && valueTest(sItems2,"name/value", "Reaction","="))
    {

        List<Element> stack1 = push(sItems2,stack);
        rFiller3(stack1, t_reaction);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)data_at0001_Tree; (4)items_at0009_Reaction_event; (5)items_at0011_Manifestation; 
* @param t_reaction - reached by target path: Bundle.entry.resource.reaction
*/
private void rFiller3(List<Element> stack, AllergyIntolerance.Reaction t_reaction) throws Exception
{
    Element sItems2 = stack.get(5);
    for(Element sValue : namedChildElements(sItems2,"value"))
    {

        List<Element> stack1 = push(sValue,stack);
        rCodeableConce(stack1, t_reaction);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)data_at0001_Tree; (4)items_at0009_Reaction_event; (5)items_at0011_Manifestation; (6)value; 
* @param t_reaction - reached by target path: Bundle.entry.resource.reaction
*/
private void rCodeableConce(List<Element> stack, AllergyIntolerance.Reaction t_reaction) throws Exception
{
    Element sValue = stack.get(6);
    for(Element sValue1 : namedChildElements(sValue,"value"))
    {
        CodeableConceptDt t_manifestatio = new CodeableConceptDt(); 
        t_reaction.addManifestation(t_manifestatio);
        CodingDt t_coding = new CodingDt(); 
        t_manifestatio.addCoding(t_coding);
        t_coding.setSystem(("http://snomed.info/sct"));
        t_coding.setDisplay(getText(sValue1));
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)data_at0001_Tree; 
* @param t_reaction - reached by target path: Bundle.entry.resource.reaction
*/
private void rFiller4(List<Element> stack, AllergyIntolerance.Reaction t_reaction) throws Exception
{
    Element sData = stack.get(3);
    for(Element sItems3 : namedChildElements(sData,"items"))
    if (valueTest(sItems3,"@archetype_node_id", "at0002","=") && valueTest(sItems3,"@xsi:type", "ELEMENT","=") && valueTest(sItems3,"name/value", "Causative agent","="))
    {

        List<Element> stack1 = push(sItems3,stack);
        rCodeableConce1(stack1, t_reaction);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)data_at0001_Tree; (4)items_at0002_Substance; 
* @param t_reaction - reached by target path: Bundle.entry.resource.reaction
*/
private void rCodeableConce1(List<Element> stack, AllergyIntolerance.Reaction t_reaction) throws Exception
{
    Element sItems3 = stack.get(4);
    for(Element sValue2 : namedChildElements(sItems3,"value"))
    {
        CodeableConceptDt t_substance = new CodeableConceptDt(); 
        t_reaction.setSubstance(t_substance);
        CodingDt t_coding1 = new CodingDt(); 
        t_substance.addCoding(t_coding1);
        t_coding1.setSystem(("http://snomed.info/sct"));

        List<Element> stack1 = push(sValue2,stack);

        Node sDisplay1 = namedChildNode(sValue2,"value");
        if (sDisplay1 != null) t_coding1.setDisplay(getText(sDisplay1));
        pFiller2(stack1, t_coding1);
    }
}

/**
* @param stack - source elements (0)composition; (1)content_at0000_Allergies_and_adverse_reactions; (2)items_at0000_Adverse_reaction_risk; (3)data_at0001_Tree; (4)items_at0002_Substance; (5)value; 
* @param t_coding1 - reached by target path: Bundle.entry.resource.reaction.substance.coding
*/
private void pFiller2(List<Element> stack, CodingDt t_coding1) throws Exception
{
    Element sValue2 = stack.get(5);
    for(Element sDefining : namedChildElements(sValue2,"defining_code"))
    {

        List<Element> stack1 = push(sDefining,stack);

        Node sCode = namedChildNode(sDefining,"code_string");
        if (sCode != null) t_coding1.setCode(getText(sCode));
    }
}

/**
* @param stack - source elements (0)composition; 
* @param target - reached by target path: Bundle
*/
private void rFiller5(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sComposer : namedChildElements(sourceTop,"composer"))
    {

        List<Element> stack1 = push(sComposer,stack);
        rBundle_Entry_1(stack1, target);
    }
}

/**
* @param stack - source elements (0)composition; (1)composer; 
* @param target - reached by target path: Bundle
*/
private void rBundle_Entry_1(List<Element> stack, Bundle target) throws Exception
{
    Element sComposer = stack.get(1);
    for(Element sName : namedChildElements(sComposer,"name"))
    {
        Bundle.Entry t_entry_Practi = new Bundle.Entry(); 
        target.addEntry(t_entry_Practi);
        Practitioner t_resource1 = new Practitioner();
        t_entry_Practi.setResource(t_resource1);
        HumanNameDt t_name = new HumanNameDt(); 
        t_resource1.setName(t_name);
        t_name.getFamily().add(new StringDt(getText(sName)));
    }
}
}
