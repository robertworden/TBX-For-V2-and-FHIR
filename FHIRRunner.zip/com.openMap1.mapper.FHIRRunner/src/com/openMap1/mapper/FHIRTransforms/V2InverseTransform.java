package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Document;
import org.w3c.dom.Node;


public class V2InverseTransform extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Sun Oct 08 20:27:47 BST 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}

// Document for transform result
private Document tDoc;


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public Element transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   tDoc = makeOutDoc();
   return topRule(root);
}

/**
* @param sourceTop
*/
private Element topRule(Element sourceTop) throws Exception
{
    if (!("Bundle".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'Bundle'");
    Element target = newElement(tDoc,"ADT_A05");
    tDoc.appendChild(target);

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rFiller(stack1, target);
    return target;
}

/**
* @param stack - source elements (0)Bundle; 
* @param target - reached by target path: ADT_A05
*/
private void rFiller(List<Element> stack, Element target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sEntry : namedChildElements(sourceTop,"entry"))
    if (valueTest(sEntry,"resource/Patient", "Patient","contains"))
    {

        List<Element> stack1 = push(sEntry,stack);
        rFiller1(stack1, target);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; 
* @param target - reached by target path: ADT_A05
*/
private void rFiller1(List<Element> stack, Element target) throws Exception
{
    Element sEntry = stack.get(1);
    for(Element sResource : namedChildElements(sEntry,"resource"))
    {

        List<Element> stack1 = push(sResource,stack);
        rPID_Type(stack1, target);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; 
* @param target - reached by target path: ADT_A05
*/
private void rPID_Type(List<Element> stack, Element target) throws Exception
{
    Element sResource = stack.get(2);
    for(Element sPatient : namedChildElements(sResource,"Patient"))
    {
        Element t_PID = newElement(tDoc,"PID");
        target.appendChild(t_PID);

        List<Element> stack1 = push(sPatient,stack);
        rCX(stack1, t_PID);
        rXPN(stack1, t_PID);
        rTS(stack1, t_PID);
        pFiller(stack1, t_PID);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; 
* @param t_PID - reached by target path: ADT_A05.PID
*/
private void pFiller(List<Element> stack, Element t_PID) throws Exception
{
    Element sPatient = stack.get(3);
    for(Element sGender : namedChildElements(sPatient,"gender"))
    {

        List<Element> stack1 = push(sGender,stack);

        Node sPID_8 = namedChildNode(sGender,"value");
        if (sPID_8 != null) t_PID.appendChild(textElement(tDoc,"PID.8",getText(sPID_8)));
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; 
* @param t_PID - reached by target path: ADT_A05.PID
*/
private void rCX(List<Element> stack, Element t_PID) throws Exception
{
    Element sPatient = stack.get(3);
    for(Element sIdentifier : namedChildElements(sPatient,"identifier"))
    {
        Element t_PID_3 = newElement(tDoc,"PID.3");
        t_PID.appendChild(t_PID_3);

        List<Element> stack1 = push(sIdentifier,stack);
        pFiller1(stack1, t_PID_3);
        rHD(stack1, t_PID_3);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; (4)identifier; 
* @param t_PID_3 - reached by target path: ADT_A05.PID.PID.3
*/
private void pFiller1(List<Element> stack, Element t_PID_3) throws Exception
{
    Element sIdentifier = stack.get(4);
    for(Element sValue : namedChildElements(sIdentifier,"value"))
    {

        List<Element> stack1 = push(sValue,stack);

        Node sCX_1 = namedChildNode(sValue,"value");
        if (sCX_1 != null) t_PID_3.appendChild(textElement(tDoc,"CX.1",getText(sCX_1)));
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; (4)identifier; 
* @param t_PID_3 - reached by target path: ADT_A05.PID.PID.3
*/
private void rHD(List<Element> stack, Element t_PID_3) throws Exception
{
    Element sIdentifier = stack.get(4);
    for(Element sSystem : namedChildElements(sIdentifier,"system"))
    {
        Element t_CX_4 = newElement(tDoc,"CX.4");
        t_PID_3.appendChild(t_CX_4);
        t_CX_4.appendChild(textElement(tDoc,"HD.3",("ISO")));

        List<Element> stack1 = push(sSystem,stack);

        Node sHD_2 = namedChildNode(sSystem,"value");
        if (sHD_2 != null) t_CX_4.appendChild(textElement(tDoc,"HD.2",getText(sHD_2)));
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; 
* @param t_PID - reached by target path: ADT_A05.PID
*/
private void rTS(List<Element> stack, Element t_PID) throws Exception
{
    Element sPatient = stack.get(3);
    for(Element sBirthDate : namedChildElements(sPatient,"birthDate"))
    {
        Element t_PID_7 = newElement(tDoc,"PID.7");
        t_PID.appendChild(t_PID_7);

        List<Element> stack1 = push(sBirthDate,stack);

        Node sTS_1 = namedChildNode(sBirthDate,"value");
        if (sTS_1 != null) t_PID_7.appendChild(textElement(tDoc,"TS.1",getText(sTS_1)));
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; 
* @param t_PID - reached by target path: ADT_A05.PID
*/
private void rXPN(List<Element> stack, Element t_PID) throws Exception
{
    Element sPatient = stack.get(3);
    for(Element sName : namedChildElements(sPatient,"name"))
    {
        Element t_PID_5 = newElement(tDoc,"PID.5");
        t_PID.appendChild(t_PID_5);

        List<Element> stack1 = push(sName,stack);
        pFiller2(stack1, t_PID_5);
        pFiller3(stack1, t_PID_5);
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; (4)name; 
* @param t_PID_5 - reached by target path: ADT_A05.PID.PID.5
*/
private void pFiller2(List<Element> stack, Element t_PID_5) throws Exception
{
    Element sName = stack.get(4);
    for(Element sFamily : namedChildElements(sName,"family"))
    {

        List<Element> stack1 = push(sFamily,stack);

        Node sXPN_1 = namedChildNode(sFamily,"value");
        if (sXPN_1 != null) t_PID_5.appendChild(textElement(tDoc,"XPN.1",getText(sXPN_1)));
    }
}

/**
* @param stack - source elements (0)Bundle; (1)entry_Patient; (2)resource; (3)Patient; (4)name; 
* @param t_PID_5 - reached by target path: ADT_A05.PID.PID.5
*/
private void pFiller3(List<Element> stack, Element t_PID_5) throws Exception
{
    Element sName = stack.get(4);
    for(Element sGiven : namedChildElements(sName,"given"))
    {

        List<Element> stack1 = push(sGiven,stack);

        Node sXPN_2 = namedChildNode(sGiven,"value");
        if (sXPN_2 != null) t_PID_5.appendChild(textElement(tDoc,"XPN.2",getText(sXPN_2)));
    }
}
}
