package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import ca.uhn.fhir.model.primitive.*;
import ca.uhn.fhir.model.dstu2.resource.BaseResource;

import ca.uhn.fhir.model.dstu2.composite.IdentifierDt;
import ca.uhn.fhir.model.dstu2.resource.Patient;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.valueset.NameUseEnum;
import ca.uhn.fhir.model.dstu2.composite.HumanNameDt;
import ca.uhn.fhir.model.dstu2.valueset.AdministrativeGenderEnum;
import com.openMap1.mapper.FHIRConversions.FHIRConverters;
import ca.uhn.fhir.model.dstu2.resource.Bundle;

public class V2Transform_dup extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Thu Oct 12 15:02:49 BST 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public BaseResource transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   return topRule(root);
}

/**
* @param sourceTop
*/
private BaseResource topRule(Element sourceTop) throws Exception
{
    if (!("ADT_A05".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'ADT_A05'");
    Bundle target = new Bundle();

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rBundle_Entry_(stack1, target);
    return target;
}

/**
* @param stack - source elements (0)ADT_A05; 
* @param target - reached by target path: Bundle
*/
private void rBundle_Entry_(List<Element> stack, Bundle target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sPID : namedChildElements(sourceTop,"PID"))
    {
        Bundle.Entry t_entry_Patien = new Bundle.Entry(); 
        target.addEntry(t_entry_Patien);
        Patient t_resource = new Patient();
        t_entry_Patien.setResource(t_resource);
        t_resource.setId(new IdDt(("001")));

        List<Element> stack1 = push(sPID,stack);
        pFiller(stack1, t_resource);
        pGender(stack1, t_resource);
        rHumanName(stack1, t_resource);
        rIdentifier(stack1, t_resource);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void pFiller(List<Element> stack, Patient t_resource) throws Exception
{
    Element sPID = stack.get(1);
    for(Element sPID1 : namedChildElements(sPID,"PID.7"))
    {

        List<Element> stack1 = push(sPID1,stack);

        Node sBirthDate = namedChildNode(sPID1,"TS.1");
        if (sBirthDate != null) t_resource.setBirthDate(new DateDt(FHIRConverters.date_V2_to_FHIR(null,getText(sBirthDate))));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void pGender(List<Element> stack, Patient t_resource) throws Exception
{
    Element sPID = stack.get(1);
    for(Element sGender : namedChildElements(sPID,"PID.8"))
    {
        t_resource.setGender(AdministrativeGenderEnum.forCode(patient_gender_conversion(getText(sGender))));
    }
}

private String patient_gender_conversion(String val)
{
     if("M".equals(val)) return "male";
     if("F".equals(val)) return "female";
     return"";
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void rHumanName(List<Element> stack, Patient t_resource) throws Exception
{
    Element sPID = stack.get(1);
    for(Element sPID2 : namedChildElements(sPID,"PID.5"))
    {
        HumanNameDt t_name = new HumanNameDt(); 
        t_resource.addName(t_name);
        t_name.setUse(NameUseEnum.forCode(("usual")));

        List<Element> stack1 = push(sPID2,stack);

        Node sXPN = namedChildNode(sPID2,"XPN.2");
        if (sXPN != null) t_name.getGiven().add(new StringDt(getText(sXPN)));

        Node sXPN1 = namedChildNode(sPID2,"XPN.1");
        if (sXPN1 != null) t_name.getFamily().add(new StringDt(getText(sXPN1)));
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; 
* @param t_resource - reached by target path: Bundle.entry.resource
*/
private void rIdentifier(List<Element> stack, Patient t_resource) throws Exception
{
    Element sPID = stack.get(1);
    for(Element sPID3 : namedChildElements(sPID,"PID.3"))
    {
        IdentifierDt t_identifier = new IdentifierDt(); 
        t_resource.addIdentifier(t_identifier);

        List<Element> stack1 = push(sPID3,stack);

        Node sValue = namedChildNode(sPID3,"CX.1");
        if (sValue != null) t_identifier.setValue(getText(sValue));
        pFiller1(stack1, t_identifier);
    }
}

/**
* @param stack - source elements (0)ADT_A05; (1)PID; (2)PID_3; 
* @param t_identifier - reached by target path: Bundle.entry.resource.identifier
*/
private void pFiller1(List<Element> stack, IdentifierDt t_identifier) throws Exception
{
    Element sPID3 = stack.get(2);
    for(Element sCX : namedChildElements(sPID3,"CX.4"))
    {

        List<Element> stack1 = push(sCX,stack);

        Node sSystem = namedChildNode(sCX,"HD.2");
        if (sSystem != null) t_identifier.setSystem(getText(sSystem));
    }
}
}
