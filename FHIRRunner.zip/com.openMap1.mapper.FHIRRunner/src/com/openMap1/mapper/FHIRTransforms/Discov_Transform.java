package com.openMap1.mapper.FHIRTransforms;

import java.util.List;
import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;


public class Discov_Transform extends BaseTransformer {

// to check that the compiled class is the correct version
public String getGeneratedDateTime() {return("Tue Nov 21 13:04:31 GMT 2017");}

// to check that the compiled class is the correct version; change version when making hand edits
public String getVersion() {return("1");}

// Document for transform result
private Document tDoc;


/**
* @param  sDoc the input document
* @ return the result of the transform
*/
public Element transform(Document sDoc) throws Exception
{
   Element root = sDoc.getDocumentElement();
   tDoc = makeOutDoc();
   return topRule(root);
}

//--------------------------------------------------------------------------------------
//                                  Bundle                                  
//--------------------------------------------------------------------------------------

/**
* @param sourceTop
*/
protected Element topRule(Element sourceTop) throws Exception
{
    if (!("database".equals(getName(sourceTop))))
        throw new Exception("Root element is not named 'database'");
    Element target = newElement(tDoc,"database");
    tDoc.appendChild(target);

    List<Element> stack1 = push(sourceTop, new Vector<Element>());
    rENCOUNTERS_Type(stack1, target);
    return target;
}

/**
* @param stack - source elements (0)database; 
* @param target - reached by target path: database
*/
protected void rENCOUNTERS_Type(List<Element> stack, Element target) throws Exception
{
    Element sourceTop = stack.get(0);
    for(Element sENCOUNTERCSV : namedChildElements(sourceTop,"ENCOUNTERCSV"))
    {
        Element t_ENCOUNTERS_ENCOUNT = newElement(tDoc,"ENCOUNTERS");
        target.appendChild(t_ENCOUNTERS_ENCOUNT);
        List<Element> stack1 = push(sENCOUNTERCSV,stack);
        rRecord_ENCOUNTERS_T(stack1, t_ENCOUNTERS_ENCOUNT);
    }
}

/**
* @param stack - source elements (0)database; (1)ENCOUNTERCSV; 
* @param t_ENCOUNTERS_ENCOUNT - reached by target path: database.ENCOUNTERS
*/
protected void rRecord_ENCOUNTERS_T(List<Element> stack, Element t_ENCOUNTERS_ENCOUNT) throws Exception
{
    Element sENCOUNTERCSV = stack.get(1);
    for(Element sRecord : namedChildElements(sENCOUNTERCSV,"record"))
    {
        Element t_record_record_ENCO = newElement(tDoc,"record");
        t_ENCOUNTERS_ENCOUNT.appendChild(t_record_record_ENCO);
        List<Element> stack1 = push(sRecord,stack);

        Node sOwningOrg = namedChildNode(sRecord,"Source");
        if (sOwningOrg != null) t_record_record_ENCO.appendChild(textElement(tDoc,"OwningOrg",getText(sOwningOrg)));

        Node sPatient = namedChildNode(sRecord,"Patient");
        if (sPatient != null) t_record_record_ENCO.appendChild(textElement(tDoc,"Patient",getText(sPatient)));

        Node sDateTimeRecorded = namedChildNode(sRecord,"Date");
        if (sDateTimeRecorded != null) t_record_record_ENCO.appendChild(textElement(tDoc,"DateTimeRecorded",getText(sDateTimeRecorded)));
        pAdminAction(stack1, t_record_record_ENCO);

        Node sService = namedChildNode(sRecord,"Class");
        if (sService != null) t_record_record_ENCO.appendChild(textElement(tDoc,"Service",getText(sService)));

        Node sSiteOfCareType = namedChildNode(sRecord,"Type");
        if (sSiteOfCareType != null) t_record_record_ENCO.appendChild(textElement(tDoc,"SiteOfCareType",getText(sSiteOfCareType)));

        Node sCompletionStatus = namedChildNode(sRecord,"Status");
        if (sCompletionStatus != null) t_record_record_ENCO.appendChild(textElement(tDoc,"CompletionStatus",getText(sCompletionStatus)));

        Node sLocation = namedChildNode(sRecord,"Location");
        if (sLocation != null) t_record_record_ENCO.appendChild(textElement(tDoc,"Location",getText(sLocation)));

        Node sResponsible_Pract = namedChildNode(sRecord,"Clinician");
        if (sResponsible_Pract != null) t_record_record_ENCO.appendChild(textElement(tDoc,"Responsible_Pract",getText(sResponsible_Pract)));
    }
}

/**
* @param stack - source elements (0)database; (1)ENCOUNTERCSV; (2)record; 
* @param t_record_record_ENCO - reached by target path: database.ENCOUNTERS.record
*/
protected void pAdminAction(List<Element> stack, Element t_record_record_ENCO) throws Exception
{
    Element sRecord = stack.get(2);
    for(Element sAdminAction : namedChildElements(sRecord,"ADT_Message_Type"))
    {
        t_record_record_ENCO.appendChild(textElement(tDoc,"AdminAction",record_ENCOUNTERS_Type_AdminAction_conversion(getText(sAdminAction))));
    }
}

protected String record_ENCOUNTERS_Type_AdminAction_conversion(String val)
{
     if("Discharge/end visit".equals(val)) return "DIS";
     if("Register a patient".equals(val)) return "REG";
     if("Admit/visit notification".equals(val)) return "ADM";
     if("Delete a patient record".equals(val)) return "DEL";
     if("Pre-admit a patient".equals(val)) return "PRE";
     return"";
}
}
